import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const dataPath = path.join(root, "public/data/projects.json");
const screenshotDir = path.join(root, "public/screenshots");
const docsDir = path.join(root, "docs");
const inventoryJsonPath = path.join(root, "data/project-inventory.json");
const inventoryCsvPath = path.join(root, "data/project-inventory.csv");

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[char]);
}

function csvCell(value) {
  const text = value === null || value === undefined ? "" : String(value);
  return `"${text.replace(/"/g, '""')}"`;
}

function csv(rows, fields) {
  return `${[fields.map(csvCell).join(","), ...rows.map((row) => fields.map((field) => csvCell(row[field])).join(","))].join("\n")}\n`;
}

function imagePaths(project) {
  return [...new Set([project.screenshot, ...(project.gallery ?? [])].filter(Boolean))];
}

const projects = JSON.parse(await fs.readFile(dataPath, "utf8"));
await fs.mkdir(docsDir, { recursive: true });
const checkedImagePaths = new Set();
const hashes = new Map();
const missingFiles = [];
for (const project of projects) {
  if (project.screenshotAudit?.state !== "verified") continue;
  for (const url of imagePaths(project)) {
    if (checkedImagePaths.has(`${project.id}:${url}`)) continue;
    checkedImagePaths.add(`${project.id}:${url}`);
    const localPath = path.join(root, "public", url.replace(/^\/+/, ""));
    try {
      const buffer = await fs.readFile(localPath);
      const digest = crypto.createHash("sha256").update(buffer).digest("hex");
      const owners = hashes.get(digest) ?? [];
      owners.push({ id: project.id, url });
      hashes.set(digest, owners);
    } catch {
      missingFiles.push({ id: project.id, url });
    }
  }
}

const duplicateScreenshots = [...hashes.values()].filter((owners) => new Set(owners.map((owner) => owner.id)).size > 1);
const verified = projects.filter((project) => project.screenshotAudit?.state === "verified");
const visibleProjects = projects.filter((project) => !project.duplicateOf);
const documentedCount = projects.filter((project) => project.catalogEvidence?.kind !== "user_supplied_url").length;
const previewCount = projects.filter((project) => project.status === "preview").length;
const directDestinations = projects.filter((project) => project.url || project.linkAudit?.candidateUrl);
const linkStateCounts = directDestinations.reduce((counts, project) => {
  const state = project.linkAudit?.state ?? "not_checked";
  counts[state] = (counts[state] ?? 0) + 1;
  return counts;
}, {});
const identityCounts = directDestinations.reduce((counts, project) => {
  const state = project.linkAudit?.identity ?? "not_checked";
  counts[state] = (counts[state] ?? 0) + 1;
  return counts;
}, {});

const inventoryRows = projects.map((project) => ({
  id: project.id,
  en: project.en,
  ar: project.ar,
  group: project.group,
  sub: project.sub,
  origin: project.origin,
  status: project.status,
  road: project.road ?? "",
  parentId: project.parentId ?? "",
  duplicateOf: project.duplicateOf ?? "",
  url: project.url ?? "",
  candidateUrl: project.linkAudit?.candidateUrl ?? "",
  screenshot: project.screenshot ?? "",
  screenshotState: project.screenshotAudit?.state ?? "pending",
  screenshotEvidence: project.screenshotAudit?.evidence ?? "",
  linkState: project.linkAudit?.state ?? "not_checked",
  linkIdentity: project.linkAudit?.identity ?? "not_checked",
  linkTitle: project.linkAudit?.pageTitle ?? "",
}));
await fs.writeFile(inventoryJsonPath, `${JSON.stringify(projects, null, 2)}\n`);
await fs.writeFile(inventoryCsvPath, csv(inventoryRows, Object.keys(inventoryRows[0] ?? {})));

const linkRows = projects
  .filter((project) => project.url || project.linkAudit?.candidateUrl)
  .map((project) => ({
    id: project.id,
    project: project.en,
    destination: project.url ?? project.linkAudit?.candidateUrl ?? "",
    sourceListingTitle: project.linkAudit?.listingTitle ?? "",
    state: project.linkAudit?.state ?? "not_checked",
    httpStatus: project.linkAudit?.statusCode ?? "",
    finalUrl: project.linkAudit?.finalUrl ?? "",
    pageTitle: project.linkAudit?.pageTitle ?? "",
    identity: project.linkAudit?.identity ?? "not_checked",
    loginRequired: project.linkAudit?.loginRequired ? "yes" : "no",
    identityEvidence: project.linkAudit?.identityEvidence ?? project.linkAudit?.recoveryNote ?? "",
    error: project.linkAudit?.error ?? "",
  }));
await fs.writeFile(path.join(docsDir, "link-audit.csv"), csv(linkRows, Object.keys(linkRows[0] ?? {})));

const screenshotRows = projects.map((project) => ({
  id: project.id,
  project: project.en,
  archiveTreatment: project.duplicateOf ? `related deployment of ${project.duplicateOf}` : "standalone project",
  state: project.screenshotAudit?.state ?? "pending",
  cover: project.screenshot ?? "",
  gallery: (project.gallery ?? []).join(" | "),
  evidence: project.screenshotAudit?.evidence ?? "No verified project-specific screenshot is available.",
  source: project.screenshotAudit?.source ?? "",
  linkState: project.linkAudit?.identity ?? "",
}));
await fs.writeFile(path.join(docsDir, "screenshot-audit.csv"), csv(screenshotRows, Object.keys(screenshotRows[0] ?? {})));

const shareGroups = duplicateScreenshots.map((owners) => `- ${owners.map((owner) => `${owner.id} (${owner.url})`).join(" and ")}`).join("\n");
const linkProblemRows = linkRows.filter((row) => row.state !== "reachable" || row.identity === "mismatch" || row.identity === "review" || row.loginRequired === "yes");
const linkProblems = linkProblemRows.length
  ? linkProblemRows.map((row) => `- **${row.id} — ${row.project}**: ${row.state}; identity ${row.identity}; HTTP ${row.httpStatus || "unknown"}; ${row.identityEvidence || row.error || "no additional detail"}`).join("\n")
  : "- No reachable-link or project-identity issues were found.";
const destinationGroups = new Map();
for (const row of linkRows) {
  const owners = destinationGroups.get(row.destination) ?? [];
  owners.push(row);
  destinationGroups.set(row.destination, owners);
}
const sharedDestinations = [...destinationGroups.entries()].filter(([, owners]) => owners.length > 1);
const sharedDestinationNotes = sharedDestinations.length
  ? sharedDestinations.map(([destination, owners]) => `- **Shared destination:** ${owners.map((owner) => `${owner.id} (${owner.project})`).join(" and ")} both point to [${destination}](${destination}). The rendered page identity is evaluated independently for each source record; only matching records expose a direct URL.`).join("\n")
  : "- No direct destination is shared by multiple source records.";
const pendingScreenshots = projects.filter((project) => project.screenshotAudit?.state !== "verified");
const screenshotSummary = [
  `- Source records: **${projects.length}** (${documentedCount} catalog records, ${previewCount} deployment-preview records).`,
  `- Distinct archive projects: **${visibleProjects.length}**; the Red Sea Global deployment preview is grouped under its documented RSG destination-management project.`,
  `- Records with verified screenshots: **${verified.length}**; records still marked unavailable/unverified: **${pendingScreenshots.length}**.`,
  `- Verified image files assigned to records: **${checkedImagePaths.size}**; missing local image paths: **${missingFiles.length}**.`,
  `- Exact screenshot bytes reused across different project IDs: **${duplicateScreenshots.length}**.`,
].join("\n");
const screenshotIssues = [
  ...(missingFiles.length ? missingFiles.map((item) => `- Missing file for **${item.id}**: \`${item.url}\``) : []),
  ...(duplicateScreenshots.length ? duplicateScreenshots.map((owners) => `- Reused image digest: ${owners.map((owner) => `${owner.id} (${owner.url})`).join(" and ")}`) : []),
].join("\n") || "- No missing image files or cross-project byte-identical screenshots were detected.";

await fs.writeFile(path.join(docsDir, "link-audit.md"), `# Project link audit

Generated from the project index and a headless browser check of each recorded direct destination. A reachable URL is not automatically considered a correct project link; the visible page identity is checked separately. No login-protected content was accessed.

## Summary

- Direct URLs and recovered candidates checked: **${directDestinations.length}**
- HTTP/link results: ${Object.entries(linkStateCounts).map(([state, count]) => `**${state}: ${count}**`).join("; ") || "none"}
- Visible identity results: ${Object.entries(identityCounts).map(([state, count]) => `**${state}: ${count}**`).join("; ") || "none"}
- Listings scanned for project links: **${matchedListingCount(projects)}** Notaq destinations were associated with catalog records.

## Issues and review items

${linkProblems}

## Notes

- The “Cloud Services Platform” listing destination renders as a Mostaka personal-care storefront, so that candidate is kept in the audit but is not exposed as that project’s direct link.
- The “Mahrous & Esraa” listing heading differed from the catalog title; its destination page identifies the project as a wedding invitation, which matches the catalog record.
- The Ask Saad page reaches its own sign-in screen. The link remains available, but the sign-in page is not used as screenshot evidence.

${sharedDestinationNotes}
`);

await fs.writeFile(path.join(docsDir, "screenshot-audit.md"), `# Project screenshot audit

Only screenshots embedded from the provided project evidence or captured from the matching public project interface are marked verified. The Notaq project-listing page, stock images, generated imagery and other projects’ screens are not used as evidence.

## Summary

${screenshotSummary}

## Remaining visual-evidence issues

${pendingScreenshots.map((project) => `- **${project.id} — ${project.en}**: ${project.screenshotAudit?.evidence || "No verified screenshot is available."}`).join("\n") || "- All records have project-specific visual evidence."}

## Integrity checks

${screenshotIssues}

${shareGroups ? `\n${shareGroups}\n` : ""}

The screenshot contact sheet includes every source record. Records without a verified project-specific screenshot are shown with an explicit unavailable label; the grouped Red Sea deployment is labeled as a related preview.
`);

const previewRecords = projects.filter((project) => project.catalogEvidence?.kind === "user_supplied_url");
const identityRows = previewRecords.map((project) => {
  const relation = project.duplicateOf
    ? `Grouped under **${project.duplicateOf}** as a related deployment; not counted as an additional project.`
    : "Kept as its own deployment-preview record; no matching same-application catalog item was established.";
  return `### ${project.en}\n\n- **Direct URL:** ${project.url ?? project.linkAudit?.candidateUrl ?? "not recorded"}\n- **Visible identity:** ${project.identityAudit?.evidence ?? project.linkAudit?.identityEvidence ?? "not verified"}\n- **Relationship decision:** ${relation}\n- **Screenshot:** ${project.screenshotAudit?.state === "verified" ? "verified live-interface capture" : "not available"}\n`;
}).join("\n");
const relatedRecords = projects.filter((project) => project.parentId && !project.duplicateOf && project.identityAudit?.relationship);
const relatedItems = relatedRecords.length
  ? relatedRecords.map((project) => `- **${project.en}** → **${project.parentId}**: ${project.identityAudit.relationship}`).join("\n")
  : "- No additional related-record relationships are recorded.";
await fs.writeFile(path.join(docsDir, "project-identity-audit.md"), `# Project identity and duplicate audit

The inventory contains **${documentedCount} documented catalog records** and **${previewCount} Cloud Run deployment-preview records**. The archive shows **${visibleProjects.length} distinct projects**, retaining every underlying source record.

## Deployment previews

${identityRows}

## Related records kept distinct

These records have a documented relationship or share an established product/client identity. They remain separate archive entries unless the relationship is explicitly marked as an alternate deployment.

${relatedItems}

## Name and destination discrepancies

- The Notaq listing labels the Mahrous & Esraa card “Law Office,” but its linked page title and content identify a wedding invitation. The destination is assigned only after the app itself confirms that identity.
- The “Cloud Services Platform” link candidate lands on a Mostaka storefront, not an application matching the catalog title. It is recorded as an identity mismatch and not shown as the project’s direct URL or screenshot.
- “Special Offer Landing Page” and “Cloud Services Platform” resolve to the same rendered storefront. They remain separate source records until there is evidence that they should be merged; no duplicate is silently removed.
`);

function matchedListingCount(data) {
  return data.filter((project) => project.linkAudit?.linkSource === "Notaq Open Project link").length;
}

const cards = [];
for (const project of projects) {
  let imageMarkup = `<div class="missing">PROJECT SCREENSHOT<br><span>NOT AVAILABLE / NOT VERIFIED</span></div>`;
  if (project.screenshotAudit?.state === "verified" && project.screenshot) {
    const localPath = path.join(root, "public", project.screenshot.replace(/^\/+/, ""));
    try {
      const bytes = await fs.readFile(localPath);
      const mime = path.extname(localPath).toLowerCase() === ".webp" ? "image/webp" : path.extname(localPath).toLowerCase() === ".png" ? "image/png" : "image/jpeg";
      imageMarkup = `<img src="data:${mime};base64,${bytes.toString("base64")}" alt="Verified project screen for ${escapeHtml(project.en)}">`;
    } catch {
      imageMarkup = `<div class="missing">SCREENSHOT FILE MISSING<br><span>${escapeHtml(project.screenshot)}</span></div>`;
    }
  }
  const grouped = project.duplicateOf ? `<span class="grouped">RELATED DEPLOYMENT · ${escapeHtml(project.duplicateOf)}</span>` : "";
  cards.push(`<article><div class="visual">${imageMarkup}<span class="state">${escapeHtml(project.screenshotAudit?.state === "verified" ? "VERIFIED" : "UNAVAILABLE")}</span></div><div class="card-copy"><div class="project-id">${escapeHtml(project.id)} ${grouped}</div><h2>${escapeHtml(project.en)}</h2><p lang="ar" dir="rtl">${escapeHtml(project.ar)}</p><div class="meta">${escapeHtml(project.group)} · ${escapeHtml(project.origin)} · ${escapeHtml(project.status)}${project.road ? ` · ${escapeHtml(project.road)}` : ""}</div></div></article>`);
}

const contactSheetHtml = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><style>
*{box-sizing:border-box}body{margin:0;background:#f4f1e7;color:#1c2a36;font:13px Arial,sans-serif}.head{padding:24px 28px;background:#172632;color:#f4f1e7}.head h1{margin:0 0 8px;font-size:24px}.head p{margin:0;color:#c7d0cb;line-height:1.5}.grid{padding:18px;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}article{overflow:hidden;border:1px solid #d9d4c8;background:#fbfaf5;break-inside:avoid}.visual{height:142px;position:relative;background:#172632;display:grid;place-items:center}.visual img{width:100%;height:100%;object-fit:contain}.state{position:absolute;right:7px;top:7px;background:#f4f1e7;padding:4px 6px;font:bold 8px Arial;letter-spacing:.08em}.missing{width:100%;height:100%;display:grid;place-content:center;text-align:center;color:#f4f1e7;font:bold 12px Arial;line-height:1.8}.missing span{font:9px Arial;color:#abb8b1}.card-copy{padding:10px}.project-id,.meta{font:9px monospace;color:#167765;line-height:1.5;overflow-wrap:anywhere}.grouped{color:#9a5e26}.card-copy h2{font-size:13px;line-height:1.35;margin:6px 0}.card-copy p{font-size:11px;margin:0 0 7px;line-height:1.5}.meta{color:#65727b}.end{padding:14px 20px;color:#65727b;font:10px monospace}
</style></head><body><header class="head"><h1>Saad Barghouth · Notaq — Project Screenshot Audit</h1><p>${visibleProjects.length} distinct projects · ${projects.length} source records · ${verified.length} records with verified screenshots<br>Only project-specific evidence is shown. Unavailable screenshots are labeled; the Red Sea deployment preview is grouped under its existing RSG project.</p></header><main class="grid">${cards.join("")}</main><footer class="end">Generated from the local project inventory. No stock or generated project screenshots are used.</footer></body></html>`;

const browser = await chromium.launch({
  headless: true,
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || "/repl/tools/bin/chromium",
  args: ["--no-sandbox"],
});
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1200 } });
  await page.setContent(contactSheetHtml, { waitUntil: "load", timeout: 30000 });
  await page.waitForTimeout(250);
  await page.screenshot({
    path: path.join(docsDir, "screenshot-contact-sheet.jpg"),
    type: "jpeg",
    quality: 82,
    fullPage: true,
  });
  await page.close();
} finally {
  await browser.close();
}

console.log(`Wrote updated inventory (${projects.length} records / ${visibleProjects.length} distinct projects), link and screenshot audits, and a contact sheet.`);