import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const dataPath = path.join(root, "public/data/projects.json");
const screenshotDir = path.join(root, "public/screenshots");
const mobileCandidates = new Set([
  "transport",
  "smart-infra",
  "ainsijam",
  "redsea",
  "academy-live",
  "empire-store",
  "kids-maps",
  "startup-landing",
  "portfolio",
  "cloud-run-preview-wky6",
  "cloud-run-preview-eec2",
]);
const forceCaptureIds = new Set(["transport"]);
const identityStopWords = new Set([
  "a", "an", "and", "the", "of", "for", "in", "to", "with", "by", "from",
  "project", "projects", "platform", "system", "website", "digital", "interactive",
  "final", "assessment", "application", "dashboard", "experience", "app", "live",
  "saad", "egypt", "portfolio", "project",
]);

function normalize(value) {
  return String(value ?? "")
    .normalize("NFKD")
    .replace(/\p{M}/gu, "")
    .toLocaleLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

function tokens(value) {
  return normalize(value)
    .split(/\s+/u)
    .filter((token) => token.length > 2 && !identityStopWords.has(token));
}

function isLoginWall(pageUrl, title, body, hasPassword) {
  const text = normalize(`${title} ${body.slice(0, 1000)}`);
  const pathSignals = /\/(auth|login|sign-in|signin)(\/|$)/i.test(new URL(pageUrl).pathname);
  const textSignals = /sign in|log in|login|تسجيل الدخول|سجل دخولك|كلمة السر|password/.test(text);
  return pathSignals || (hasPassword && textSignals);
}

function classifyIdentity(project, pageTitle, bodyText, finalUrl) {
  const hostname = new URL(finalUrl).hostname.toLowerCase();
  const titleAndBody = normalize(`${pageTitle} ${bodyText.slice(0, 3500)}`);
  const urlText = normalize(finalUrl);

  if (project.id === "cloud-platform" && /mostaka|مستكة/.test(titleAndBody)) {
    return {
      state: "mismatch",
      evidence: "The Notaq link resolves to a Mostaka personal-care storefront, not a cloud services platform.",
    };
  }
  if (project.id === "albakhira-content" && /قاعة الباخرة|al bakhera|albakhera/.test(titleAndBody)) {
    return {
      state: "mismatch",
      evidence: "The Notaq destination displays the Al Bakhira celebration hall and booking/contact details, not a digital content platform.",
    };
  }
  if (project.id === "academy-live" && titleAndBody.includes("منصة الاستاذ") && /دروس|الثانوية العامة|تسجيل الدخول|الامتحان/.test(titleAndBody)) {
    return {
      state: "confirmed",
      evidence: "The Notaq-linked page is an Arabic teacher-led learning platform with lessons, exams and student progress content; the different title is the teacher's name.",
    };
  }
  if (project.id === "elite-management" && /elite catering|النخبة للحفلات|catering/.test(titleAndBody)) {
    return {
      state: "mismatch",
      evidence: "The Notaq destination is the Elite Catering public marketing site; it does not identify or present the catalogued business-management system.",
    };
  }
  if (project.id === "empire-store" && /empire brand/.test(titleAndBody) && /streetwear|ستريت وير/.test(titleAndBody)) {
    return {
      state: "confirmed",
      evidence: "The Notaq-linked storefront identifies itself as Empire Brand and presents Egyptian streetwear products.",
    };
  }
  if (project.id === "ai-studio" && /قاعة الياقوت|qsr al yaqoot|ruby hall/.test(titleAndBody)) {
    return {
      state: "mismatch",
      evidence: "The Notaq destination identifies a celebration venue, not an AI services studio.",
    };
  }
  if (project.id === "kids-maps" && titleAndBody.includes("الخرايط") && titleAndBody.includes("التعليمية") && /الصف الخامس|كنوز مصر|خريطة رحلتك/.test(titleAndBody)) {
    return {
      state: "confirmed",
      evidence: "The linked page identifies an educational map experience for children and fifth-grade Egyptian curriculum content.",
    };
  }
  if (project.id === "teba-store" && /qasr tayiba palace|قصر طيبة/.test(titleAndBody)) {
    return {
      state: "mismatch",
      evidence: "The Notaq destination is a Qasr Tayiba Palace teaser page and does not present the catalogued Teba Store.",
    };
  }
  if (project.id === "worklog" && /worklog/.test(titleAndBody) && /work hours|ساعات العمل/.test(titleAndBody)) {
    return {
      state: "confirmed",
      evidence: "The page title and body identify WorkLog as a work-hours and attendance application; the application itself requires sign-in.",
    };
  }
  if (project.id === "startup-landing" && /techventure/.test(titleAndBody) && /techcorp/.test(titleAndBody)) {
    return {
      state: "confirmed",
      evidence: "The Notaq-linked page is a technology-startup landing-page demo; its visible TechVenture/TechCorp branding and Korean AI copy are recorded as rendered.",
    };
  }
  if (project.id === "portfolio" && hostname === "www.barghouth.me" && /saad barghouth/.test(titleAndBody)) {
    return {
      state: "confirmed",
      evidence: "The live page is Saad Barghouth's professional GIS/Web GIS portfolio.",
    };
  }
  if (project.id === "transport" && hostname === "transport-platform-apps.vercel.app") {
    return { state: "confirmed", evidence: "The URL host and visible page identify the Ministry of Transport applications platform." };
  }
  if (project.id === "smart-infra" && hostname.includes("geoinformatics-smart-infrastructure")) {
    return { state: "confirmed", evidence: "The direct project hostname identifies the smart-infrastructure application." };
  }
  if (project.id === "ainsijam" && hostname.includes("ain-sijam") && /عين سيجام|عينسيجام/.test(titleAndBody)) {
    return { state: "confirmed", evidence: "The direct project hostname and visible Arabic product name identify Ain Sijam." };
  }
  if (project.id === "redsea" && hostname === "rsgis.vercel.app" && /red sea global|البحر الأحمر/.test(titleAndBody)) {
    return { state: "confirmed", evidence: "The live interface identifies the Red Sea Global GIS monitoring application." };
  }
  if (project.id === "cloud-run-preview-wky6" && /vodafone passive network/.test(titleAndBody) && /gis utility dashboard/.test(titleAndBody)) {
    return { state: "confirmed", evidence: "Visible page title and heading identify Vodafone Passive Network — GIS Utility Dashboard." };
  }
  if (project.id === "cloud-run-preview-eec2" && /red sea global pitch/.test(titleAndBody) && /remote sensing|الاستشعار عن بعد/.test(titleAndBody)) {
    return { state: "confirmed", evidence: "Visible page title and interface identify a Red Sea Global geospatial and remote-sensing pitch." };
  }
  if (project.id === "mahrous-esraa" && /mahrous/.test(titleAndBody) && /wedding invitation|دعوة/.test(titleAndBody)) {
    return { state: "confirmed", evidence: "The destination title and page content identify the Mahrous & Esraa wedding invitation, despite the different Notaq listing heading." };
  }
  if (project.id === "ask-saad" && /ask saad/.test(titleAndBody) && /gis|نظم المعلومات الجغرافية/.test(titleAndBody)) {
    return { state: "confirmed", evidence: "The page title and sign-in copy identify the Ask Saad GIS assistant." };
  }
  if (project.id === "offer-landing" && /service-339591511497/.test(hostname) && /mostaka|مستكة/.test(titleAndBody) && /offer|عرض|99/.test(titleAndBody)) {
    return { state: "confirmed", evidence: "The direct Notaq destination opens a branded special-offer storefront page." };
  }
  if (project.catalogEvidence?.slug && urlText.includes(normalize(project.catalogEvidence.slug))) {
    return { state: "confirmed", evidence: `The project-specific URL path contains the documented source slug “${project.catalogEvidence.slug}”.` };
  }

  const expected = new Set([...tokens(project.en), ...tokens(project.ar)]);
  const observed = new Set(tokens(`${pageTitle} ${bodyText.slice(0, 3500)}`));
  const matched = [...expected].filter((token) => observed.has(token));
  if (matched.length >= Math.min(2, expected.size) && matched.length > 0) {
    return { state: "confirmed", evidence: `The live page title/content includes project-specific terms: ${matched.slice(0, 6).join(", ")}.` };
  }

  if (matched.length > 0 || normalize(project.linkAudit?.listingTitle).length > 0) {
    return {
      state: "review",
      evidence: matched.length
        ? `Only partial title/content overlap was found (${matched.join(", ")}); the page is not used as screenshot evidence.`
        : "The destination loaded, but its visible title/content did not establish a reliable project identity.",
    };
  }

  return {
    state: "review",
    evidence: "The destination loaded, but no reliable project-specific identity signal was found in its visible content.",
  };
}

async function inspectProject(project, browser) {
  const activeUrl = project.url || project.linkAudit?.candidateUrl;
  if (!activeUrl) return { projectId: project.id, skipped: true, reason: "no direct URL" };

  const page = await browser.newPage({
    viewport: { width: 1600, height: 1000 },
    ignoreHTTPSErrors: true,
  });
  const pageErrors = [];
  page.on("pageerror", (error) => pageErrors.push(error.message));
  let response = null;
  let pageTitle = "";
  let bodyText = "";
  let finalUrl = activeUrl;
  let statusCode = null;
  let auditError = null;
  let identity = { state: "review", evidence: "No identity evidence collected." };
  let loginRequired = false;
  let screenshot = null;
  let mobile = null;

  try {
    response = await page.goto(activeUrl, { waitUntil: "domcontentloaded", timeout: 16000 });
    await page.waitForTimeout(500);
    finalUrl = page.url();
    statusCode = response?.status() ?? null;
    pageTitle = await page.title().catch(() => "");
    bodyText = await page.locator("body").innerText({ timeout: 3000 }).catch(() => "");
    const hasPassword = (await page.locator('input[type="password"]').count().catch(() => 0)) > 0;
    loginRequired = isLoginWall(finalUrl, pageTitle, bodyText, hasPassword);
    identity = classifyIdentity(project, pageTitle, bodyText, finalUrl);
    if (project.id === "worklog" && identity.state === "confirmed") loginRequired = true;

    const responseOk = statusCode === null || (statusCode >= 200 && statusCode < 400);
    const isTransportHome = project.id === "transport";
    const mayCapture = responseOk
      && identity.state === "confirmed"
      && !loginRequired
      && (project.screenshotAudit?.state !== "verified" || forceCaptureIds.has(project.id));

    if (mayCapture) {
      const filename = `${project.id}-live.jpg`;
      screenshot = `/screenshots/${filename}`;
      await page.screenshot({
        path: path.join(screenshotDir, filename),
        type: "jpeg",
        quality: 86,
        fullPage: false,
      });

      if (mobileCandidates.has(project.id)) {
        await page.setViewportSize({ width: 390, height: 844 });
        await page.waitForTimeout(400);
        const fit = await page.evaluate(() => ({
          width: window.innerWidth,
          scrollWidth: document.documentElement.scrollWidth,
          hasViewportMeta: Boolean(document.querySelector('meta[name="viewport"]')),
        }));
        if (fit.hasViewportMeta && fit.scrollWidth <= fit.width + 12) {
          const mobileFilename = `${project.id}-live-mobile.jpg`;
          mobile = `/screenshots/${mobileFilename}`;
          await page.screenshot({
            path: path.join(screenshotDir, mobileFilename),
            type: "jpeg",
            quality: 82,
            fullPage: false,
          });
        }
      }
    }
  } catch (error) {
    auditError = String(error).split("\n")[0].slice(0, 240);
    finalUrl = page.url();
  } finally {
    await page.close();
  }

  const previousLinkAudit = project.linkAudit ?? {};
  const fromListing = previousLinkAudit.linkSource === "Notaq Open Project link"
    && Boolean(previousLinkAudit.candidateUrl)
    && (!project.url || project.url === previousLinkAudit.candidateUrl);
  const isMismatch = identity.state === "mismatch";
  if (fromListing && !isMismatch && !auditError && (statusCode === null || statusCode < 400)) {
    project.url = activeUrl;
    if (project.status === "catalog") project.status = "live";
  }
  if (fromListing && isMismatch) {
    project.url = null;
    project.status = "catalog";
    project.screenshot = null;
    project.gallery = [];
    project.screenshotAudit = {
      state: "pending",
      evidence: `${identity.evidence} The mismatched destination is not shown as the direct project link or as screenshot evidence.`,
      source: null,
    };
  }

  project.linkAudit = {
    ...previousLinkAudit,
    checkedAt: new Date().toISOString(),
    checkedUrl: activeUrl,
    finalUrl,
    statusCode,
    pageTitle,
    state: auditError ? "unreachable" : statusCode !== null && statusCode >= 400 ? "http_error" : "reachable",
    identity: identity.state,
    identityEvidence: identity.evidence,
    loginRequired,
    consoleErrors: pageErrors.slice(0, 5),
    error: auditError,
    mobileViewport: mobile ? "captured; no horizontal overflow detected" : mobileCandidates.has(project.id) ? "not captured or not responsive" : null,
  };

  if (screenshot) {
    const gallery = Array.isArray(project.gallery) ? project.gallery : [];
    project.screenshot = screenshot;
    project.gallery = [...new Set([screenshot, mobile, ...gallery].filter(Boolean))];
    project.screenshotAudit = {
      state: "verified",
      source: activeUrl,
      evidence: `Captured directly from the project's own live interface at ${finalUrl}. ${identity.evidence}`,
      capturedAt: new Date().toISOString(),
      viewport: "1600×1000",
      mobileCapture: mobile,
    };
  } else if (loginRequired && identity.state === "confirmed") {
    project.screenshotAudit = {
      ...(project.screenshotAudit ?? {}),
      state: project.screenshotAudit?.state === "verified" ? "verified" : "pending",
      source: activeUrl,
      evidence: `The project URL is reachable and its identity is confirmed, but it stops at a login screen; the login page is not used as project screenshot evidence.`,
    };
  } else if (identity.state === "mismatch") {
    project.screenshotAudit = {
      ...(project.screenshotAudit ?? {}),
      state: project.screenshotAudit?.state === "verified" && project.id !== "cloud-platform" ? "verified" : "pending",
      evidence: `${identity.evidence} This page is not used as screenshot evidence for this project.`,
    };
  }

  return {
    projectId: project.id,
    url: activeUrl,
    statusCode,
    pageTitle,
    identity: identity.state,
    loginRequired,
    screenshot,
    mobile,
    error: auditError,
  };
}

const projects = JSON.parse(await fs.readFile(dataPath, "utf8"));
await fs.mkdir(screenshotDir, { recursive: true });
const browser = await chromium.launch({
  headless: true,
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || "/repl/tools/bin/chromium",
  args: ["--no-sandbox"],
});

const records = projects.filter((project) => project.url || project.linkAudit?.candidateUrl);
const results = [];
let next = 0;
async function worker() {
  while (next < records.length) {
    const project = records[next++];
    try {
      const result = await inspectProject(project, browser);
      results.push(result);
      console.log(`${result.projectId}: ${result.statusCode ?? "no HTTP status"} · ${result.identity}${result.loginRequired ? " · login required" : ""}${result.screenshot ? " · screenshot captured" : ""}${result.error ? ` · ${result.error}` : ""}`);
    } catch (error) {
      const message = String(error).split("\n")[0].slice(0, 240);
      project.linkAudit = {
        ...(project.linkAudit ?? {}),
        checkedAt: new Date().toISOString(),
        state: "unreachable",
        identity: "review",
        error: message,
      };
      results.push({ projectId: project.id, error: message, identity: "review" });
      console.log(`${project.id}: audit failed · ${message}`);
    }
  }
}

try {
  await Promise.all(Array.from({ length: Math.min(4, records.length) }, () => worker()));
} finally {
  await browser.close();
}

await fs.writeFile(dataPath, `${JSON.stringify(projects, null, 2)}\n`);
const captured = results.filter((result) => result.screenshot).length;
const confirmed = results.filter((result) => result.identity === "confirmed").length;
const mismatches = results.filter((result) => result.identity === "mismatch").length;
console.log(`\nAudited ${results.length} destinations: ${confirmed} identities confirmed, ${mismatches} mismatches, ${captured} new desktop screenshots.`);