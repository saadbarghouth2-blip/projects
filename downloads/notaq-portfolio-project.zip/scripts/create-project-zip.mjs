import fs from "node:fs/promises";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const downloadsDir = path.join(root, "downloads");
const archive = path.join(downloadsDir, "notaq-portfolio-project.zip");

await fs.mkdir(downloadsDir, { recursive: true });
await fs.rm(archive, { force: true });
const result = spawnSync("zip", [
  "-q",
  "-r",
  archive,
  ".",
  "-x",
  "./node_modules/*",
  "./dist/*",
  "./.vite/*",
  "./downloads/*",
  "./*.log",
], { cwd: root, stdio: "inherit" });

if (result.error) throw result.error;
if (result.status !== 0) throw new Error(`zip exited with status ${result.status}`);
const stats = await fs.stat(archive);
console.log(`Created ${path.relative(root, archive)} (${(stats.size / 1024 / 1024).toFixed(2)} MiB).`);