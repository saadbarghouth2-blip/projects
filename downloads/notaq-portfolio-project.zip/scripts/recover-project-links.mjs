import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const dataPath = path.join(root, "public/data/projects.json");
const listingUrl = "https://xn--2gbwk.site/en/projects/";
const manualAliases = new Map([
  ["mahrous & esraa law office", "mahrous-esraa"],
  ["ask saad gis assistant", "ask-saad"],
]);
const stopWords = new Set([
  "a", "an", "and", "the", "of", "for", "in", "to", "with", "by",
  "project", "projects", "platform", "system", "website", "digital",
  "interactive", "final", "assessment", "application",
]);

function normalize(value) {
  return String(value ?? "")
    .normalize("NFKD")
    .replace(/\p{M}/gu, "")
    .toLocaleLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

function words(value) {
  return normalize(value).split(/\s+/u).filter((word) => word && !stopWords.has(word));
}

const projects = JSON.parse(await fs.readFile(dataPath, "utf8"));
const browser = await chromium.launch({
  headless: true,
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || "/repl/tools/bin/chromium",
  args: ["--no-sandbox"],
});

let listings;
try {
  const page = await browser.newPage({ viewport: { width: 1480, height: 1000 } });
  await page.goto(listingUrl, { waitUntil: "domcontentloaded", timeout: 45000 });
  await page.waitForTimeout(1000);
  listings = await page.evaluate(() => {
    const entries = [];
    for (const heading of document.querySelectorAll("h2,h3,h4")) {
      const title = heading.textContent?.trim().replace(/\s+/g, " ");
      if (!title || title.length > 120) continue;
      let card = heading;
      let match = null;
      for (let level = 0; level < 6; level += 1) {
        card = card.parentElement;
        if (!card) break;
        if (card.querySelectorAll("h3,h4").length > 1) break;
        const anchors = [...card.querySelectorAll("a[href]")].filter((anchor) => {
          const label = `${anchor.textContent ?? ""} ${anchor.getAttribute("aria-label") ?? ""}`;
          return /open project|visit project|فتح المشروع/i.test(label) || anchor.target === "_blank";
        });
        if (anchors.length === 1) {
          match = anchors[0];
          break;
        }
      }
      if (match && !entries.some((entry) => entry.url === match.href)) {
        entries.push({ title, url: match.href });
      }
    }
    return entries;
  });
  await page.close();
} finally {
  await browser.close();
}

const notaqProjects = projects.filter((project) => project.origin === "Notaq");
const matched = [];
const unmatched = [];

for (const entry of listings) {
  const aliasId = manualAliases.get(normalize(entry.title));
  let candidates = aliasId
    ? notaqProjects.filter((project) => project.id === aliasId)
    : notaqProjects;

  if (!aliasId) {
    const entryWords = new Set(words(entry.title));
    const scored = candidates
      .map((project) => {
        const projectWords = new Set(words(project.en));
        const score = [...entryWords].filter((word) => projectWords.has(word)).length;
        return { project, score };
      })
      .sort((a, b) => b.score - a.score);
    const bestScore = scored[0]?.score ?? 0;
    const requiredScore = Math.min(2, entryWords.size);
    candidates = scored
      .filter((candidate) => candidate.score === bestScore && candidate.score >= requiredScore)
      .map((candidate) => candidate.project);
  }

  if (candidates.length !== 1) {
    unmatched.push({ title: entry.title, url: entry.url, candidateIds: candidates.map((project) => project.id) });
    continue;
  }

  const project = candidates[0];
  const headingMismatch = normalize(project.en) !== normalize(entry.title);
  project.linkAudit = {
    ...(project.linkAudit ?? {}),
    candidateUrl: entry.url,
    listingUrl,
    listingTitle: entry.title,
    linkSource: "Notaq Open Project link",
    listingHeadingMatch: !headingMismatch,
    recoveryState: "candidate",
    recoveryNote: headingMismatch
      ? "The listing heading differs from the catalog title; the linked project's own page must confirm identity before the URL is used."
      : "The link came from the matching project's Open Project action; the destination still requires a live identity check.",
  };
  matched.push({ id: project.id, title: entry.title, url: entry.url, headingMismatch });
}

// The two Cloud Run apps now have names visible on their public interfaces.
// The Red Sea pitch is retained as a related deployment of the existing RSG
// destination-management project, not as a second project in the archive.
const vodafone = projects.find((project) => project.id === "cloud-run-preview-wky6");
if (vodafone) {
  Object.assign(vodafone, {
    en: "Vodafone Passive Network — GIS Utility Dashboard",
    ar: "شبكة فودافون السلبية — لوحة نظم المعلومات الجغرافية",
    group: "GIS",
    sub: "Passive network utility dashboard · deployment preview",
    desc: "A GIS utility dashboard for a passive network, with cable filters, operational alerts and layer inspection.",
    arDesc: "لوحة نظم معلومات جغرافية لشبكة سلبية، تتضمن مرشحات للكابلات وتنبيهات تشغيلية وطبقات للشبكة.",
    status: "preview",
    identityAudit: {
      state: "confirmed_from_live_interface",
      evidence: "The public page title reads “Vodafone Passive Network” and its visible heading identifies a GIS utility dashboard.",
      relationship: "No same-application match was confirmed with the catalog entry about Vodafone GIS proof-of-concept data conversion.",
    },
  });
  vodafone.tags = ["Vodafone", "GIS", "Utility network", "Deployment preview"];
  vodafone.catalogEvidence = {
    ...vodafone.catalogEvidence,
    identityVerified: true,
    relationshipReviewed: true,
    mayDuplicateExistingProject: false,
  };
  vodafone.screenshotAudit = {
    ...vodafone.screenshotAudit,
    state: "pending",
    evidence: "The live application identity is visible; a project-specific screenshot will be captured from this URL if the interface loads without a login wall.",
  };
}

const redSeaPreview = projects.find((project) => project.id === "cloud-run-preview-eec2");
if (redSeaPreview) {
  Object.assign(redSeaPreview, {
    en: "Red Sea Global — Geospatial Intelligence & Remote-Sensing Pitch",
    ar: "البحر الأحمر العالمية — منصة الذكاء الجغرافي والاستشعار عن بعد",
    group: "GIS",
    sub: "Remote-sensing pitch · related deployment preview",
    desc: "A geospatial and remote-sensing pitch experience for exploring Red Sea Global destinations, satellite bands and spatial context.",
    arDesc: "تجربة عرض للذكاء الجغرافي والاستشعار عن بعد لاستكشاف وجهات البحر الأحمر العالمية ونطاقات الأقمار الصناعية والسياق المكاني.",
    status: "preview",
    parentId: "rsg-destinations",
    duplicateOf: "rsg-destinations",
    identityAudit: {
      state: "confirmed_from_live_interface",
      evidence: "The page identifies itself as a Red Sea Global geospatial and remote-sensing pitch and presents destination and satellite-band content.",
      relationship: "Grouped as a related deployment of the documented RSG Destination Management prototype; retained as a source record but not counted as another project.",
    },
  });
  redSeaPreview.tags = ["Red Sea Global", "Remote sensing", "Geospatial intelligence", "Deployment preview"];
  redSeaPreview.catalogEvidence = {
    ...redSeaPreview.catalogEvidence,
    identityVerified: true,
    relationshipReviewed: true,
    resolvedDuplicateOf: "rsg-destinations",
    mayDuplicateExistingProject: true,
  };
  redSeaPreview.screenshotAudit = {
    ...redSeaPreview.screenshotAudit,
    state: "pending",
    evidence: "The live page identity is confirmed as a Red Sea Global remote-sensing pitch related to the RSG destination-management record; screenshot capture is pending.",
  };
}

const relatedRecords = [
  {
    id: "kids-maps",
    parentId: "kunuz",
    identityAudit: {
      state: "confirmed_from_live_interface",
      evidence: "The live page is an educational map experience for children and fifth-grade Egyptian curriculum content.",
      relationship: "Related to the broader Kunuz Egypt interactive-map platform by shared product name and learning focus; retained as its own curriculum-specific experience because its content and interface differ.",
    },
  },
  {
    id: "albakhira-content",
    parentId: "albakhira-events",
    identityAudit: {
      state: "mismatch",
      evidence: "The Notaq destination currently displays the Al Bakhira celebration hall and booking/contact details, not a digital content platform.",
      relationship: "Related by the Al Bakhira venue identity to the catalogued Events Hall entry; this destination is not treated as proof of the digital-content record.",
    },
  },
  {
    id: "elite-management",
    parentId: "elite-one",
    identityAudit: {
      state: "mismatch",
      evidence: "The Notaq destination is an Elite Catering public marketing/contact site, not the catalogued business-management system.",
      relationship: "The destination shares the Elite Catering brand with the separate Elite One website record; the records remain distinct and the mismatched system URL is withheld.",
    },
  },
];
for (const related of relatedRecords) {
  const project = projects.find((item) => item.id === related.id);
  if (!project) continue;
  project.parentId = related.parentId;
  project.identityAudit = related.identityAudit;
  project.catalogEvidence = {
    ...project.catalogEvidence,
    relationshipReviewed: true,
    relatedTo: related.parentId,
  };
}

await fs.writeFile(dataPath, `${JSON.stringify(projects, null, 2)}\n`);

console.log(`Scanned ${listings.length} Notaq project destinations; matched ${matched.length} records.`);
console.log(`Notaq records without a matched destination: ${notaqProjects.filter((project) => !project.linkAudit?.candidateUrl).length}.`);
for (const item of matched) {
  console.log(`${item.id}: ${item.url}${item.headingMismatch ? ` [heading differs: ${item.title}]` : ""}`);
}
for (const item of unmatched) {
  console.log(`UNMATCHED: ${item.title} → ${item.url} [${item.candidateIds.join(", ")}]`);
}