/*
 * Saad Barghouth — Project Index
 * Single-page React + TypeScript portfolio, no React build-time dependencies.
 * Every displayed image must be a genuine, project-specific screenshot. No synthetic covers.
 */

type Category = 'GIS' | 'Dashboards' | 'Platforms' | 'Systems' | 'Business' | 'Commerce' | 'Education' | 'AI' | 'Culture';
type Status = 'live' | 'catalog' | 'case' | 'concept' | 'preview';
type Lang = 'en' | 'ar';
type View = 'grid' | 'list';
type Sort = 'featured' | 'az' | 'za';
type OriginFilter = 'all' | 'Notaq' | 'GIS' | 'Transport' | 'Web';
interface Project {
  parentId?:string; road?:string; catalogEvidence?:{kind?:string;source?:string;sourceFiles?:string[];httpStatusTested?:boolean};
  id:string; en:string; ar:string; group:Category; sub:string; desc:string; arDesc:string;
  url:string|null; sourceUrl:string|null; tags:string[]; featured:boolean; origin:string;
  cover?:string|null; status:Status; screenshot:string|null; gallery?:string[];
}
interface State {
  projects:Project[]; loaded:boolean; error:string;
  lang:Lang; dark:boolean; filter:Category|'All'; origin:OriginFilter;
  query:string; sort:Sort; liveOnly:boolean; view:View;
  selectedId:string|null; aboutScreenshots:boolean; showTop:boolean;
}

type IconName='arrow'|'external'|'search'|'globe'|'sun'|'moon'|'grid'|'list'|'filter'|'close'|'copy'|'check'|'location'|'layers'|'chart'|'code'|'move'|'menu'|'chevron'|'arrow-down';
const cats:(Category|'All')[]=['All','GIS','Dashboards','Platforms','Systems','Business','Commerce','Education','AI','Culture'];
const tagsByCategory:Record<Category,{name:string;ar:string;color:string}>={
 GIS:{name:'GIS & Mapping',ar:'نظم المعلومات الجغرافية',color:'#15b5b7'},
 Dashboards:{name:'Dashboards',ar:'لوحات المعلومات',color:'#8780f7'},
 Platforms:{name:'Digital Platforms',ar:'المنصات الرقمية',color:'#48c7a6'},
 Systems:{name:'Business Systems',ar:'أنظمة الأعمال',color:'#bca0ee'},
 Business:{name:'Websites',ar:'المواقع الإلكترونية',color:'#eeb06f'},
 Commerce:{name:'E-commerce',ar:'المتاجر',color:'#eb8b84'},
 Education:{name:'Education',ar:'التعليم التفاعلي',color:'#76ce8e'},
 AI:{name:'AI & Automation',ar:'الذكاء الاصطناعي',color:'#a8a0fb'},
 Culture:{name:'Experiences',ar:'التجارب الرقمية',color:'#ecc581'}
};
const displayCategory=(c:Category|'All',lang:Lang) => c==='All'?(lang==='ar'?'الكل':'All projects'):(lang==='ar'?tagsByCategory[c].ar:tagsByCategory[c].name);
const strings={
 en:{projects:'PROJECTS INDEX',browse:'EXPLORE ALL',heroEyebrow:'SAAD BARGHOUTH  /  NOTAQ STUDIO',heroLine1:'Made to work.',heroLine2:'Made to matter.',heroDesc:'Geospatial intelligence, interactive dashboards, meaningful digital products and web experiences — a complete archive in one place.',heroButton:'Explore all projects',heroSecondary:'Featured projects',allTitle:'Every project.\nOne place.',allSub:'A complete collection of geospatial solutions and digital experiences. Explore by field, search by technology, or open a project to see more.',selection:'THE SPOTLIGHT',featured:'Selected work',featuredDesc:'A closer look at the applications, interfaces and systems that define the work.',explore:'EXPLORE THE ARCHIVE',allProjects:'Project archive',search:'Search projects, tools, sectors...',sortFeatured:'Curated order',sortAZ:'Name A to Z',sortZA:'Name Z to A',liveOnly:'Live links only',projectsShown:'projects found',of:'of',results:'results',allSources:'All work',studio:'Notaq Studio',geo:'Geospatial work',web:'Web & systems',view:'View live project',details:'Explore details',catalog:'Notaq project listing',preview:'Unverified preview',case:'Project study',planned:'Concept / planned',live:'Live project',noLive:'No public demo link is currently available for this project.',source:'Project source / original catalog',technologies:'TOOLS & TECHNOLOGIES',kind:'PROJECT CATEGORY',sourceLabel:'COLLECTION',work:'PROJECT OVERVIEW',close:'Close',share:'Copy project link',copied:'Copied!',empty:'Nothing matched your filters.',emptySub:'Try a different keyword or clear the filters.',clear:'Clear filters',top:'Back to top',footer:'An archive of things built and ideas explored.',footerNote:'Curated collection · Saad Barghouth / Notaq',screenshot:'REAL PROJECT SCREENSHOT',artwork:'PREVIEW NOT AVAILABLE',readNote:'Saved screenshots are matched to their exact projects; live websites can display a fresh screenshot rendered from their own public URL. Missing project links still need confirmation.',loading:'Loading projects...',error:'Could not load projects. Please serve the folder from a local web server or deploy it.',sort:'Sort',origin:'Collection',count:'entries',demo:'LIVE SITE',closeIcon:'Close details'},
 ar:{projects:'فهرس المشاريع',browse:'استكشف المشاريع',heroEyebrow:'سعد برغوث  /  نُطق',heroLine1:'مشاريع لها قيمة.',heroLine2:'وتصميم له هدف.',heroDesc:'منصات GIS والخرائط ولوحات المعلومات والأنظمة الرقمية وتجارب الويب — كل المشاريع في مكان واحد.',heroButton:'كل المشاريع',heroSecondary:'الأعمال المميزة',allTitle:'كل المشاريع.\nفي مكان واحد.',allSub:'مجموعة كاملة من أعمال النظم الجغرافية والحلول الرقمية. ابحث باسم المشروع أو التقنية، أو اختار التصنيف المناسب.',selection:'أعمال مختارة',featured:'أبرز المشاريع',featuredDesc:'مشاريع ومنصات تفاعلية تمثل مجالات العمل والتقنيات المستخدمة.',explore:'تصفح المجموعة كاملة',allProjects:'أرشيف المشاريع',search:'ابحث عن مشروع أو تقنية أو قطاع...',sortFeatured:'الترتيب المختار',sortAZ:'أ إلى ي',sortZA:'ي إلى أ',liveOnly:'مشاريع بروابط مباشرة فقط',projectsShown:'مشروع',of:'من',results:'نتائج',allSources:'جميع الأعمال',studio:'مشاريع نُطق',geo:'المشاريع الجغرافية',web:'المنصات والمواقع',view:'فتح المشروع',details:'تفاصيل المشروع',catalog:'عرض المشروع في نُطق',preview:'معاينة قيد التحقق',case:'دراسة مشروع',planned:'فكرة أو تصور',live:'مشروع مباشر',noLive:'لا يوجد رابط مباشر مؤكد لهذا المشروع حاليًا.',source:'معرض نُطق الأصلي',technologies:'التقنيات المستخدمة',kind:'تصنيف المشروع',sourceLabel:'مصدر المشروع',work:'نظرة عامة',close:'إغلاق',share:'نسخ رابط المشروع',copied:'اتنسخ!',empty:'مفيش مشاريع مطابقة للفلاتر.',emptySub:'جرب كلمة تانية أو امسح الفلاتر.',clear:'مسح الفلاتر',top:'للأعلى',footer:'مجموعة أعمال ومنصات وتجارب رقمية.',footerNote:'معرض أعمال سعد برغوث / نُطق',screenshot:'صورة حقيقية من المشروع',artwork:'صورة المشروع غير متاحة',readNote:'اللقطات المحفوظة مرتبطة بمشاريعها الصحيحة؛ ويمكن عرض صورة مباشرة للموقع من رابطه الأصلي. المشاريع بدون رابط مؤكد ما زالت تحتاج صورة فعلية.',loading:'تحميل المشاريع...',error:'تعذر تحميل البيانات، شغّل المشروع من سيرفر محلي أو ارفعه للاستضافة.',sort:'الترتيب',origin:'المصدر',count:'مشروع',demo:'الموقع المباشر',closeIcon:'إغلاق التفاصيل'}
};
const t=(lang:Lang,key:keyof typeof strings.en)=>strings[lang][key];
const title=(p:Project,lang:Lang)=>lang==='ar'?p.ar:p.en;
const desc=(p:Project,lang:Lang)=>lang==='ar'?p.arDesc:p.desc;
function icon(name:IconName,size=20){
 const a:any={width:size,height:size,viewBox:'0 0 24 24',fill:'none',stroke:'currentColor',strokeWidth:1.8,strokeLinecap:'round',strokeLinejoin:'round','aria-hidden':'true'};
 let paths:any;
 switch(name){
 case 'arrow':paths=<g><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></g>;break;
 case 'external':paths=<g><path d="M13 5h6v6"/><path d="m19 5-9 9"/><path d="M19 13v6H5V5h6"/></g>;break;
 case 'search':paths=<g><circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.5 15.5 5 5"/></g>;break;
 case 'globe':paths=<g><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c-5 5-5 13 0 18M12 3c5 5 5 13 0 18"/></g>;break;
 case 'sun':paths=<g><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></g>;break;
 case 'moon':paths=<path d="M20.3 15.2A8.8 8.8 0 0 1 8.8 3.7a9 9 0 1 0 11.5 11.5Z"/>;break;
 case 'grid':paths=<g><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></g>;break;
 case 'list':paths=<g><path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6h1M3 12h1M3 18h1"/></g>;break;
 case 'filter':paths=<g><path d="M4 7h16M7 12h10M10 17h4"/></g>;break;
 case 'close':paths=<path d="M5 5l14 14M19 5 5 19"/>;break;
 case 'copy':paths=<g><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></g>;break;
 case 'check':paths=<path d="m4 13 5 5L20 6"/>;break;
 case 'location':paths=<g><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></g>;break;
 case 'layers':paths=<g><path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/></g>;break;
 case 'chart':paths=<g><path d="M3 3v18h18"/><path d="m7 16 4-5 4 3 5-8"/></g>;break;
 case 'code':paths=<g><path d="m8 7-5 5 5 5m8-10 5 5-5 5m-3-13-2 16"/></g>;break;
 case 'move':paths=<g><path d="m12 2-4 4m4-4 4 4M12 2v20m0 0-4-4m4 4 4-4M2 12l4-4m-4 4 4 4M2 12h20m0 0-4-4m4 4-4 4"/></g>;break;
 case 'menu':paths=<path d="M4 7h16M4 12h16M4 17h16"/>;break;
 case 'chevron':paths=<path d="m9 6 6 6-6 6"/>;break;
 case 'arrow-down':paths=<g><path d="M12 4v16m0 0-6-6m6 6 6-6"/></g>;break;
 }
 return <svg {...a}>{paths}</svg>;
}
const statusLabel=(p:Project,lang:Lang)=>t(lang,p.status==='live'?'live':p.status==='catalog'?'catalog':p.status==='preview'?'preview':p.status==='concept'?'planned':'case');

/**
 * Website screenshots are requested only for the EXACT public URL of a project.
 * Thum.io remotely renders that live page; this is not an AI-generated image.
 * Remote screenshots are NOT marked as independently verified or bundled in
 * the source ZIP. A broken site never gets an unrelated fallback photo.
 */
const liveScreen=(url:string|null):string|null=>{
 if(!url)return null;
 try {
  const u=new URL(url);
  if(u.protocol!=='https:'&&u.protocol!=='http:')return null;
  return 'https://image.thum.io/get/noanimate/width/1280/crop/820/maxAge/24/'+u.href;
 }catch{return null;}
};
class Cover extends React.Component<{p:Project; kind?:string;lang:Lang},{attempt:number;ready:boolean}> {
 constructor(props:{p:Project;kind?:string;lang:Lang}){super(props);this.state={attempt:0,ready:false};}
 componentDidUpdate(prev:{p:Project}){
  if(prev.p.id!==this.props.p.id)this.setState({attempt:0,ready:false});
 }
 render(){
  const p=this.props.p,attempt=this.state.attempt,ready=this.state.ready;
  const possible:{src:string;source:'verified'|'remote'}[]=[];
  if(p.screenshot)possible.push({src:p.screenshot.startsWith('/')?'.'+p.screenshot:p.screenshot,source:'verified'});
  const remote=liveScreen(p.url);
  if(remote)possible.push({src:remote,source:'remote'});
  const active=possible[attempt];
  const hasAny=possible.length>0;
  const exhausted=hasAny&&!active;
  return <div className={'project-cover screenshot-only '+(this.props.kind||'')+(hasAny?' has-image-source':' no-image-source')}>
    {!ready?<div className="screenshot-missing" aria-label={t(this.props.lang,'artwork')}>
       <span className="missing-graphic">{icon('layers',30)}</span>
       <span>{exhausted?(this.props.lang==='ar'?'تعذّر تحميل صورة الموقع':'Screenshot could not load'):(hasAny?(this.props.lang==='ar'?'جاري تحميل صورة الموقع...':'Loading website screenshot...'):t(this.props.lang,'artwork'))}</span>
       <small>{!hasAny?(this.props.lang==='ar'?'محتاجين رابط المشروع أو صورة من واجهته':'Direct site link or original screenshot needed'):(this.props.lang==='ar'?'لو الموقع لا يستجيب لن نعرض صورة بديلة':'No unrelated substitute image will appear')}</small>
    </div>:null}
    {active?<img key={p.id+'-'+attempt} className={'cover-real '+(ready?'ready':'')} src={active.src} alt={(active.source==='verified'?'Original project interface: ':'Live screenshot request for: ')+p.en} loading="lazy" referrerPolicy="no-referrer" onLoad={(e:any)=>{if(e.target.naturalWidth>=300&&e.target.naturalHeight>=160)this.setState({ready:true});else this.setState({attempt:attempt+1,ready:false});}} onError={()=>this.setState({attempt:attempt+1,ready:false})}/>:null}
    {ready&&active?<span className="visual-type">{active.source==='verified'?t(this.props.lang,'screenshot'):(this.props.lang==='ar'?'صورة من رابط المشروع':'SITE SCREENSHOT')}</span>:null}
  </div>;
 }
}

class App extends React.Component<{},State> {
 searchInput:HTMLInputElement|null=null;
 modalCloseButton:HTMLButtonElement|null=null;
 lastFocus:HTMLElement|null=null;
 onKey=(e:KeyboardEvent)=>{if(e.key==='Escape'&&this.state.selectedId)this.close();if(e.key==='/'&&!this.state.selectedId&&!(e.target instanceof HTMLInputElement)&&!(e.target instanceof HTMLTextAreaElement)){e.preventDefault();this.searchInput&&this.searchInput.focus();}};
 onScroll=()=>this.setState({showTop:window.scrollY>650});
 constructor(props:{}){
  super(props);
  const params=new URLSearchParams(location.search);
  this.state={projects:[],loaded:false,error:'',lang:params.get('lang')==='ar'?'ar':'en',dark:false,filter:'All',origin:'all',query:'',sort:'featured',liveOnly:false,view:'grid',selectedId:params.get('project'),aboutScreenshots:false,showTop:false};
 }
 componentDidMount(){
   window.addEventListener('keydown',this.onKey);window.addEventListener('scroll',this.onScroll,{passive:true});
   document.body.classList.toggle('dark',this.state.dark);
   document.documentElement.lang=this.state.lang;document.documentElement.dir=this.state.lang==='ar'?'rtl':'ltr';
   fetch('./data/projects.json').then(r=>{if(!r.ok)throw Error('HTTP '+r.status);return r.json();}).then((list:Project[])=>{
     this.setState({projects:list,loaded:true},()=>{if(this.state.selectedId&&!list.some(p=>p.id===this.state.selectedId))this.close();});
   }).catch(()=>this.setState({loaded:true,error:'load'}));
 }
 componentWillUnmount(){window.removeEventListener('keydown',this.onKey);window.removeEventListener('scroll',this.onScroll);}
 componentDidUpdate(_p:{},prev:State){
   if(prev.lang!==this.state.lang){document.documentElement.lang=this.state.lang;document.documentElement.dir=this.state.lang==='ar'?'rtl':'ltr';document.title=(this.state.lang==='ar'?'كل المشاريع':'All projects')+' — Saad Barghouth · Notaq';}
   if(prev.dark!==this.state.dark)document.body.classList.toggle('dark',this.state.dark);
   if(prev.selectedId!==this.state.selectedId){document.body.classList.toggle('modal-open',!!this.state.selectedId);if(this.state.selectedId){this.lastFocus=document.activeElement as HTMLElement;setTimeout(()=>this.modalCloseButton?.focus(),0);} else this.lastFocus?.focus();}
 }
 updateRoute(id:string|null){try{const u=new URL(location.href);if(id)u.searchParams.set('project',id);else u.searchParams.delete('project');history.replaceState(null,'',u.toString());}catch{}}
 open=(id:string)=>{this.updateRoute(id);this.setState({selectedId:id});};
 close=()=>{this.updateRoute(null);this.setState({selectedId:null});};
 toggleLanguage=()=>{let l:Lang=this.state.lang==='ar'?'en':'ar';this.setState({lang:l});try{const u=new URL(location.href);if(l==='ar')u.searchParams.set('lang','ar');else u.searchParams.delete('lang');history.replaceState(null,'',u.toString());}catch{}};
 reset=()=>{this.setState({filter:'All',query:'',origin:'all',sort:'featured',liveOnly:false});};
 filtered(){const {projects,filter,origin,query,sort,liveOnly}=this.state;
   let result=projects.filter(p=>(filter==='All'||p.group===filter)&&(origin==='all'||p.origin===origin||(origin==='Web'&&p.origin==='Concept'))&&(!liveOnly||(p.status==='live'&&!!p.url)));
   if(query.trim()){const search=query.trim().toLocaleLowerCase();result=result.filter(p=>[p.en,p.ar,p.desc,p.arDesc,p.sub,p.group,p.origin,...p.tags].join(' ').toLocaleLowerCase().includes(search));}
   if(sort==='az')result.sort((a,b)=>title(a,this.state.lang).localeCompare(title(b,this.state.lang)));
   if(sort==='za')result.sort((a,b)=>title(b,this.state.lang).localeCompare(title(a,this.state.lang)));
   return result;
 }
 scrollToAll=()=>document.getElementById('all-work')?.scrollIntoView({behavior:'smooth'});
 projectCard(p:Project,large=false){const lang=this.state.lang;return <article key={p.id} className={'work-card '+(large?'featured-work':'')+(this.state.view==='list'&&!large?' list-work':'')+(!p.url&&!p.screenshot?' awaiting-screen':'')} style={{'--category-color':tagsByCategory[p.group].color} as any}>
   <div className="work-image-wrap" onClick={()=>this.open(p.id)} role="button" tabIndex={0} onKeyDown={(e:any)=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();this.open(p.id);}}} aria-label={title(p,lang)}>
     <Cover p={p} lang={lang}/><span className={'status-chip status-'+p.status}><span className="mini-circle"/>{statusLabel(p,lang)}</span>
     <div className="hover-reveal"><span>{t(lang,'details')} {icon('arrow',16)}</span></div>
   </div>
   <div className="work-content"><div className="work-meta"><span className="tiny-number">{p.origin==='Notaq'?'NOTAQ':p.origin==='GIS'?'GEO':p.origin==='Transport'?'TRANSPORT':'DIGITAL'}</span><span className="work-category">{displayCategory(p.group,lang)}</span></div>
     <h3 onClick={()=>this.open(p.id)}>{title(p,lang)}</h3><p>{desc(p,lang)}</p>
     <div className="tag-list">{p.tags.slice(0,large?4:3).map(tag=><span key={tag}>{tag}</span>)}</div>
     <div className="work-card-bottom"><button className="text-button" onClick={()=>this.open(p.id)}>{t(lang,'details')} {icon('arrow',17)}</button>{p.url?<a className="external-round" target="_blank" rel="noopener noreferrer" href={p.url} title={t(lang,'view')} onClick={(e:any)=>e.stopPropagation()}>{icon('external',18)}</a>:null}</div>
   </div>
 </article>;}
 share=(p:Project)=>{const url=new URL(location.href);url.searchParams.set('project',p.id);navigator.clipboard?.writeText(url.toString()).then(()=>{const el=document.getElementById('share-label');if(el){el.textContent=t(this.state.lang,'copied');setTimeout(()=>{if(el)el.textContent=t(this.state.lang,'share');},1700);}}).catch(()=>{});};
 modal(){const {projects,selectedId,lang}=this.state;const p=projects.find(q=>q.id===selectedId);if(!p)return null;return <div className="modal-backdrop" onMouseDown={(e:any)=>{if(e.target===e.currentTarget)this.close();}} role="presentation"><section className="detail-modal" role="dialog" aria-modal="true" aria-label={title(p,lang)}>
    <div className="modal-top"><span className="modal-top-eyebrow">PROJECT FILE <span className="little-cyan">/</span> {String(projects.indexOf(p)+1).padStart(2,'0')}</span><div className="modal-top-controls"><button id="share-label" className="share-control" onClick={()=>this.share(p)}>{icon('copy',15)} {t(lang,'share')}</button><button ref={(el:any)=>this.modalCloseButton=el} aria-label={t(lang,'closeIcon')} className="close-control" onClick={this.close}>{icon('close',20)}</button></div></div>
    <div className="detail-scroll"><div className="detail-image"><Cover p={p} kind="modal-cover" lang={lang}/></div>
    {p.gallery&&p.gallery.length>1?<div className="verified-gallery"><div className="gallery-heading">{lang==='ar'?'صور فعلية من داخل المشروع':'Actual screens from this project'} · {p.gallery.length}</div><div className="verified-thumbs">{p.gallery.map((photo,i)=><a href={photo.startsWith('/')?'.'+photo:photo} target="_blank" rel="noopener noreferrer" key={photo} aria-label={lang==='ar'?'افتح الصورة كاملة':'Open full image'}><img src={photo.startsWith('/')?'.'+photo:photo} alt={title(p,lang)+' – '+(i+1)}/></a>)}</div></div>:null}
    <div className="detail-body">
    <div className="detail-classification"><span className="detail-cat">{displayCategory(p.group,lang)}</span><span className={'detail-status status-'+p.status}>{statusLabel(p,lang)}</span></div>
    <h2>{title(p,lang)}</h2><p className="detail-description">{desc(p,lang)}</p><div className="detail-pieces"><div><span>{t(lang,'kind')}</span><strong>{displayCategory(p.group,lang)}</strong></div><div><span>{t(lang,'sourceLabel')}</span><strong>{p.origin==='Notaq'?'Notaq Studio':p.origin==='GIS'?'GIS / Geospatial':p.origin==='Concept'?'Concept':p.origin==='Transport'?'Transport / Individual GIS app':'Digital Products'}</strong></div></div>
    <h4>{t(lang,'technologies')}</h4><div className="detail-tags">{p.tags.length?p.tags.map(tag=><span key={tag}>{tag}</span>):<span>{displayCategory(p.group,lang)}</span>}</div>
    <div className="detail-actions">{p.url?<a className="primary-action" href={p.url} target="_blank" rel="noopener noreferrer">{t(lang,'view')}{icon('external',19)}</a>:<div className="no-direct-link">{t(lang,'noLive')}</div>}{p.sourceUrl?<a className="secondary-action" href={p.sourceUrl} target="_blank" rel="noopener noreferrer">{t(lang,'source')} {icon('arrow',17)}</a>:null}</div>
    <p className="screenshot-disclaimer">{t(lang,'readNote')}</p>
    </div></div>
 </section></div>;}
 render(){const {projects,loaded,error,lang,dark,filter,origin,query,sort,liveOnly,view,selectedId,showTop}=this.state;const d=strings[lang],shown=this.filtered();const featured=['transport','smart-infra','transport-dashboard-ismailia-development-impact','gis-automator'].map(id=>projects.find(p=>p.id===id)).filter((p):p is Project=>!!p);
 const total=projects.length;const live=projects.filter(x=>x.status==='live'&&!!x.url).length;const notaq=projects.filter(x=>x.origin==='Notaq').length;const gis=projects.filter(x=>x.origin==='GIS').length;
 return <div className="app-root">
  <header className="site-header"><div className="header-inner"><a className="brand" href="#top" aria-label="Projects archive"><span className="brand-sign"><span className="brand-n">S<span>.</span></span></span><span className="brand-stack"><strong>SAAD BARGHOUTH</strong><small>{d.projects} <b>/</b> NOTAQ</small></span></a>
   <nav className="header-actions" aria-label="Portfolio controls"><span className="header-counter">{String(total).padStart(2,'0')} <em>PROJECTS</em></span><button className="header-button" aria-label="Toggle color theme" onClick={()=>this.setState({dark:!dark})}>{icon(dark?'sun':'moon',19)}</button><button className="language-button" onClick={this.toggleLanguage}>{icon('globe',16)}<span>{lang==='en'?'العربية':'English'}</span></button><button className="nav-projects" onClick={this.scrollToAll}>{d.browse}{icon('arrow',17)}</button></nav></div></header>
  <main id="top"><div className="page-shell">
   <section className="hero" aria-labelledby="hero-title"><div className="hero-text"><div className="hero-eyebrow"><span className="eyebrow-glow"/>{d.heroEyebrow} <span className="hero-hairline"/> <span className="hero-year">EST. 2023 — 2026</span></div><h1 id="hero-title">{d.heroLine1}<br/><em>{d.heroLine2}</em></h1><p className="hero-description">{d.heroDesc}</p><div className="hero-buttons"><button className="hero-cta" onClick={this.scrollToAll}>{d.heroButton}{icon('arrow',19)}</button><a className="hero-link" href="#selected-work">{d.heroSecondary}{icon('arrow-down',18)}</a></div><div className="hero-stats"><div><strong>{total}<span>+</span></strong><small>{d.count}</small></div><div><strong>{notaq}</strong><small>NOTAQ STUDIO</small></div><div><strong>{projects.filter(p=>p.origin==='Transport').length}</strong><small>{lang==='ar'?'تطبيق نقل مستقل':'TRANSPORT APPS'}</small></div></div></div>
      <div className="hero-art" aria-hidden="true"><div className="hero-orbit one"/><div className="hero-orbit two"/><div className="hero-floating float-one"><img src="./screenshots/transport-main.webp" alt=""/></div><div className="hero-floating float-two"><img src="./screenshots/gis-automator-main.webp" alt=""/></div><div className="hero-floating float-three"><img src="./screenshots/smart-infra-main.webp" alt=""/></div><div className="hero-ruler"><span>REAL PROJECTS</span><span>REAL SCREENS</span></div></div>
    <div className="hero-deco">PROJECTS &nbsp; · &nbsp; DIGITAL PRODUCTS &nbsp; · &nbsp; GEOSPATIAL</div></section>
   <section className="selected-section" id="selected-work"><div className="section-intro"><div className="section-intro-left"><span className="section-kicker"><i/> {d.selection} <span> / 01</span></span><h2>{d.featured}<span className="colored-dot">.</span></h2></div><p>{d.featuredDesc}</p></div>
      {!loaded?<div className="loading-state">{d.loading}</div>:<div className="spotlight-grid">{featured.map((p,i)=><div key={p.id} className={'spotlight-item spotlight-'+i}>{this.projectCard(p,true)}</div>)}</div>}
   </section>
   <section className="collection-section" id="all-work"><div className="section-intro collection-intro"><div className="section-intro-left"><span className="section-kicker"><i/> {d.explore} <span> / 02</span></span><h2>{d.allTitle.split('\n').map((l,i)=><span key={i}>{l}{i===0?<br/>:null}</span>)}<span className="colored-dot">.</span></h2></div><p>{d.allSub}</p></div>
    <div className="toolbar"><div className="toolbar-top"><label className="search-field">{icon('search',20)}<input ref={(e:any)=>this.searchInput=e} value={query} type="search" placeholder={d.search} onChange={(e:any)=>this.setState({query:e.target.value})} aria-label={d.search}/><kbd>/</kbd></label><div className="toolbar-functions"><label className="sort-box"><span>{icon('filter',16)}</span><select value={sort} aria-label={d.sort} onChange={(e:any)=>this.setState({sort:e.target.value as Sort})}><option value="featured">{d.sortFeatured}</option><option value="az">{d.sortAZ}</option><option value="za">{d.sortZA}</option></select></label><div className="view-switch"><button className={view==='grid'?'active':''} aria-label="Grid" aria-pressed={view==='grid'} onClick={()=>this.setState({view:'grid'})}>{icon('grid',17)}</button><button className={view==='list'?'active':''} aria-label="List" aria-pressed={view==='list'} onClick={()=>this.setState({view:'list'})}>{icon('list',18)}</button></div></div></div>
     <div className="category-scroller" role="group" aria-label="Project categories">{cats.map(c=>{let count=c==='All'?projects.length:projects.filter(p=>p.group===c).length;return <button key={c} className={'category-filter '+(filter===c?'active':'')} aria-pressed={filter===c} onClick={()=>this.setState({filter:c})}>{displayCategory(c,lang)} <span>{String(count).padStart(2,'0')}</span></button>;})}</div>
     <div className="sub-toolbar"><div className="origin-filters">{(['all','Notaq','GIS','Transport','Web'] as OriginFilter[]).map(g=><button key={g} aria-pressed={origin===g} className={origin===g?'active':''} onClick={()=>this.setState({origin:g})}>{g==='all'?d.allSources:g==='Notaq'?d.studio:g==='GIS'?d.geo:g==='Transport'?(lang==='ar'?'تطبيقات النقل':'Transport apps'):d.web}</button>)}</div><label className="only-live"><input type="checkbox" checked={liveOnly} onChange={(e:any)=>this.setState({liveOnly:e.target.checked})}/><span className="fake-checkbox">{icon('check',11)}</span>{d.liveOnly}</label></div>
    </div>
    <div className="results-bar"><div><strong>{String(shown.length).padStart(2,'0')}</strong><span>{d.of} {total} {d.projectsShown}</span></div>{query||filter!=='All'||liveOnly||origin!=='all'?<button onClick={this.reset}>{icon('close',14)} {d.clear}</button>:<span className="all-visible">{live} {d.live} <span>·</span> {notaq} NOTAQ</span>}</div>
    {!loaded?<div className="loading-state">{d.loading}</div>:error?<div className="empty-results">{d.error}</div>:shown.length?<div className={'all-projects-grid '+(view==='list'?'compact-view':'')}>{shown.map(p=>this.projectCard(p))}</div>:<div className="empty-results"><span>{icon('search',37)}</span><h3>{d.empty}</h3><p>{d.emptySub}</p><button onClick={this.reset}>{d.clear}</button></div>}
    <div className="archive-end"><div className="archive-end-line"/><span>{String(shown.length).padStart(2,'0')} / {String(total).padStart(2,'0')} &nbsp; • &nbsp; {d.footer}</span><div className="archive-end-line"/></div>
   </section>
  </div></main>
  <footer className="site-footer"><div className="footer-inner"><div className="footer-wordmark">SAAD <span>×</span> NOTAQ</div><span>{d.footerNote}</span><button onClick={()=>window.scrollTo({top:0,behavior:'smooth'})}>{d.top}{icon('arrow',16)}</button></div><div className="foot-screenshot-note">{d.readNote}</div></footer>
  {showTop?<button aria-label={d.top} className="back-top" onClick={()=>window.scrollTo({top:0,behavior:'smooth'})}>{icon('arrow-down',20)}</button>:null}
  {selectedId?this.modal():null}
 </div>;
 }
}
ReactDOM.render(<App/>,document.getElementById('root'));
