import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const all=JSON.parse(fs.readFileSync(path.join(root,'public/data/projects.json'),'utf8'));
const hashes=new Map();const missing=[];let originals=0,pictures=0;
for(const p of all){
 const list=p.gallery||[];
 if(p.screenshot){
  if(p.screenshotAudit?.state!=='verified')throw Error('Image not verified: '+p.id);
  if(!list.includes(p.screenshot))throw Error('Cover must be included in gallery: '+p.id);
  originals++;
  for(const src of list){
   const file=path.join(root,'public',src.replace(/^\//,''));
   if(!fs.existsSync(file))throw Error('Missing real file: '+file);
   const hash=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
   if(hashes.has(hash) && hashes.get(hash)!==p.id)throw Error('Same image for different projects: '+p.id+' + '+hashes.get(hash));
   hashes.set(hash,p.id);pictures++;
  }
 }else{
  if(list.length>0)throw Error('Gallery without verified cover: '+p.id);
  missing.push(p.id);
 }
}
if(all.length!==95)throw Error('Expected 93 documented catalog entries and 2 user-supplied preview links');
if(all.filter(p=>p.status==='preview').length!==2)throw Error('Expected two unverified preview deployments');
if(all.some(p=>p.status==='preview' && (p.screenshot || p.screenshotAudit?.state==='verified')))throw Error('Unverified deployments must not claim a verified screenshot');
if(fs.existsSync(path.join(root,'public/covers')))throw Error('AI generated covers were not removed');
console.log(`PASS: ${all.length} projects, ${originals} checked project-specific covers, ${pictures} corresponding images`);
console.log(`PENDING: ${missing.length} projects still need direct project screenshots`);
console.log(missing.join(', '));
