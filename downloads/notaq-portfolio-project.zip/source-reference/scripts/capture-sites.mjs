/**
 * Screenshot only THE ORIGINAL project website.
 * Never screenshot a Notaq gallery card and pretend it is the project.
 *
 *  npm install
 *  npx playwright install chromium
 *  npm run capture:all
 *
 * Captures every publicly reachable exact project and resolves missing live links
 * from the corresponding card in the original Notaq projects gallery.
 * A project that fails matching or capture remains image-free (audit pending).
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dataPath = path.join(root, 'public', 'data', 'projects.json');
const screenshotDir = path.join(root, 'public', 'screenshots');
const currentArgs=process.argv.slice(2);
const resolveNotaq = currentArgs.includes('--resolve-notaq');
const updateExisting = currentArgs.includes('--recapture');
const only = currentArgs.find(x => x.startsWith('--project='))?.split('=')[1];
const projects = JSON.parse(await fs.readFile(dataPath, 'utf8'));
await fs.mkdir(screenshotDir,{recursive:true});
const {chromium} = await import('playwright');
const browser=await chromium.launch({headless:true});
let captured=0, skipped=0, unresolved=0, failed=0;
const normalize=s=>String(s||'').normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]+/gu,'').trim();

async function discoverNotaqLinks(){
 const page=await browser.newPage({viewport:{width:1480,height:1000}});
 try{
  await page.goto('https://xn--2gbwk.site/en/projects/',{waitUntil:'domcontentloaded',timeout:45000});
  await page.waitForTimeout(3000);
  const matches=await page.evaluate(()=>{
   const headings=[...document.querySelectorAll('h2,h3,h4')];
   const entries=[];
   for(const heading of headings){
    const title=heading.textContent?.trim();if(!title||title.length>110)continue;
    let card=heading,found=null;
    for(let level=0;level<6;level++){
     card=card.parentElement;if(!card)break;
     // Don't walk to the entire project grid and accidentally take other cards' links.
     const otherHeadings=card.querySelectorAll('h3,h4').length;
     if(otherHeadings>1)break;
     const links=[...card.querySelectorAll('a[href]')].filter(a =>
       /open project|فتح المشروع|visit|live/i.test(a.textContent||a.getAttribute('aria-label')||'')||a.target==='_blank'
     );
     if(links.length===1){found=links[0];break;}
    }
    if(found){entries.push({title,url:found.href});}
   }
   return entries;
  });
  return matches;
 }finally{await page.close();}
}

async function validateAndCapture(project){
 const page=await browser.newPage({viewport:{width:1550,height:920},deviceScaleFactor:1});
 try{
  const response=await page.goto(project.url,{waitUntil:'domcontentloaded',timeout:47000});
  if(!response||response.status()>=400)throw Error('HTTP '+(response?.status()??'no response'));
  await page.waitForTimeout(3300);
  await page.evaluate(async()=>{try{await document.fonts.ready;}catch{};window.scrollTo(0,0);});
  await page.waitForTimeout(700);
  const info=await page.evaluate(()=>({title:document.title,body:(document.body?.innerText||'').slice(0,1100),width:document.body?.scrollWidth||0, height:document.body?.scrollHeight||0,panels:document.querySelectorAll('canvas,svg,main,img').length}));
  const errText=(info.title+' '+info.body).toLowerCase();
  if(/\b(404|403|not found|access denied|deployment not found|page does not exist|site not found|server error)\b/.test(errText) && info.body.length<450){throw Error('Site displays an error page');}
  if(info.body.trim().length<35 && info.panels<2)throw Error('Website did not visibly render');
  const filename=`${project.id}-actual.png`;
  await page.screenshot({path:path.join(screenshotDir,filename),fullPage:false,animations:'disabled'});
  project.screenshot='/screenshots/'+filename;
  project.gallery=[project.screenshot];
  project.screenshotAudit={state:'verified',source:'playwright_actual_project_url',url:page.url(),capturedAt:new Date().toISOString(),evidence:'Exact project live URL was loaded and the visible viewport was captured.'};
  console.log('CAPTURED',project.id,page.url(),info.title);
  captured++;
 }catch(e){failed++;console.log('PENDING',project.id,String(e).slice(0,170));}
 finally{await page.close();}
}

try{
 if(resolveNotaq){
  try{
   const cards=await discoverNotaqLinks();
   console.log('Notaq project-card links found:',cards.length);
   for(const p of projects){
    if(p.origin!=='Notaq'||p.url)continue;
    const match=cards.filter(c=>normalize(c.title)===normalize(p.en)||normalize(c.title)===normalize(p.ar));
    if(match.length!==1){console.log('UNRESOLVED TITLE:',p.en);continue;}
    const candidate=match[0].url;
    const url=new URL(candidate);
    if(!['https:','http:'].includes(url.protocol))continue;
    // Avoid mistaking the Notaq overview/gallery for the project itself.
    if(url.hostname==='xn--2gbwk.site'&&/\/projects\/?$/i.test(url.pathname))continue;
    p.url=candidate;
    console.log('RESOLVED VERIFIED CARD:',p.en,'=>',p.url);
   }
  }catch(e){console.error('Original Notaq gallery not accessible:',String(e).slice(0,200));}
 }
 for(const p of projects){
  if(only&&p.id!==only)continue;
  if(!p.url){unresolved++;console.log('MISSING URL',p.id);continue;}
  const old=p.screenshot?.startsWith('/screenshots/')?path.join(root,'public',p.screenshot.slice(1)):null;
  if(!updateExisting&&old&&await fs.stat(old).then(()=>true,()=>false)){
   skipped++;continue;
  }
  await validateAndCapture(p);
 }
 await fs.writeFile(dataPath,JSON.stringify(projects,null,2)+'\n');
}finally{await browser.close();}
console.log(JSON.stringify({captured,skipped,unresolved,failed},null,2));
console.log('No screenshot is generated for a project unless the exact app URL renders successfully.');
