import fs from 'node:fs';import path from 'node:path';
const dist='dist';fs.rmSync(dist,{recursive:true,force:true});fs.mkdirSync(dist,{recursive:true});
fs.cpSync('public',dist,{recursive:true});
fs.copyFileSync('public/styles.css',path.join(dist,'styles.css'));
fs.copyFileSync('.build/main.js',path.join(dist,'main.js'));
let html=fs.readFileSync('index.html','utf8').replace(/\/src\/main\.tsx/g,'./main.js').replace(/href="\//g,'href="./').replace(/src="\//g,'src="./');
fs.writeFileSync(path.join(dist,'index.html'),html);
fs.rmSync('.build',{recursive:true,force:true});
console.log('Standalone build ready: dist/index.html (React + TypeScript compiled).');
