# Saad Barghouth / Notaq — Project Index (React + TypeScript)

One-page bilingual portfolio of **93 cataloged projects/application entries plus 2 newly provided Cloud Run preview links**. The two deployments have not been counted as two *verified unique* projects: their names and whether they duplicate existing projects cannot be confirmed until the sites can be inspected.

## Verified app inventory

- 23 projects from the original Notaq portfolio listing.
- 42 direct-link apps individually identified in transportation presentation files (out of a reported 78 apps in the transport platform).
- 28 other GIS, systems, web, and survey projects/case studies.
- 2 additionally supplied Google Cloud Run previews, separately labeled **Preview / Identity pending**.

## Latest user-added URLs

1. https://ais-pre-wky6oqrv4sqsmfc2u255y4-765485755783.europe-west2.run.app/
2. https://ais-pre-eec2t27f2vkdxv75lhrmiw-631023896665.europe-west2.run.app/

The Cloud Run pages were not accessible from the current environment; do not invent project titles or claim that a screenshot or status check succeeded. They currently appear as separate **deployment links** pending identification and deduplication.

## Start locally

```bash
npm install
npm run dev
```

Build and audit:

```bash
npm run build
npm run audit
```

For live project screenshots with browser + network access:

```bash
npx playwright install chromium
npm run capture:all
npm run build
```

The screenshot workflow captures only the exact original app URL, not a synthetic or reused image. For projects whose URLs are restricted or missing, use genuine screenshot files from each project. Current verified images and pending screenshots are tracked in `IMAGE_PROVENANCE.md` and `SCREENS_NEEDED.md`.

## Files

- `src/main.tsx` — one-page React/TypeScript catalog.
- `public/data/projects.json` — names, direct links, screenshots and per-project evidence.
- `scripts/capture-sites.mjs` — Playwright capture and discovery workflow.
- `scripts/audit-screens.mjs` — checks screenshot-to-project associations.
- `dist/` — production static HTML/CSS/JS output after build.
