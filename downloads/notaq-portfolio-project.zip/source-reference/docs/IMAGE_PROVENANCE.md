# Image Provenance Audit

Every linked cover must be a genuine inside-project screenshot, not a generic illustration or image of another project.

Verified covers: **46**. Remaining without locally verified screenshot: **49**.

- `transport`: /screenshots/transport-main.webp — **verified** — provided_project_evidence
- `smart-infra`: /screenshots/smart-infra-overview.webp — **verified** — provided_project_evidence
- `gis-automator`: /screenshots/gis-automator-main.webp — **verified** — provided_project_evidence
- `transport-dashboard-5c855c890c`: /screenshots/transport-dashboard-5c855c890c.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-dashboard-4236f7c912`: /screenshots/transport-dashboard-4236f7c912.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-dashboard-49446055c2`: /screenshots/transport-dashboard-49446055c2.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-storymap-92d2a80d7f`: /screenshots/transport-storymap-92d2a80d7f.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-ismailia-urban`: /screenshots/transport-dashboard-ismailia-urban.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-dashboard-ismailia-development-impact`: /screenshots/cairo-impact-main.webp — **verified** — transport_presentation
- `transport-dashboard-ismailia-agriculture`: /screenshots/transport-dashboard-ismailia-agriculture.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-dashboard-ismailia-prices`: /screenshots/transport-dashboard-ismailia-prices.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-storymap-ismailia`: /screenshots/transport-storymap-ismailia.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-686d8234e8`: /screenshots/transport-dashboard-686d8234e8.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-8a75afd782`: /screenshots/transport-dashboard-8a75afd782.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-4b4547b902`: /screenshots/transport-dashboard-4b4547b902.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-storymap-739c03527e`: /screenshots/transport-storymap-739c03527e.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-ab7611e2f4`: /screenshots/transport-dashboard-ab7611e2f4.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-dashboard-b99ee8d8fc`: /screenshots/transport-dashboard-b99ee8d8fc.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-dashboard-04811fcd6f`: /screenshots/transport-dashboard-04811fcd6f.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-storymap-3678b8faa7`: /screenshots/transport-storymap-3678b8faa7.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-064fecc5d9`: /screenshots/transport-dashboard-064fecc5d9.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-989c5ff2f9`: /screenshots/transport-dashboard-989c5ff2f9.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-2529bc0ae6`: /screenshots/transport-dashboard-2529bc0ae6.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-storymap-3c8f04f4d0`: /screenshots/transport-storymap-3c8f04f4d0.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-1cb1e42f43`: /screenshots/transport-dashboard-1cb1e42f43.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-97daea1db8`: /screenshots/transport-dashboard-97daea1db8.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-687e564801`: /screenshots/transport-dashboard-687e564801.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-storymap-dahshur`: /screenshots/transport-storymap-dahshur.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-3e59ea73ec`: /screenshots/transport-dashboard-3e59ea73ec.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-dashboard-5a3aaa3b3a`: /screenshots/transport-dashboard-5a3aaa3b3a.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-dashboard-58fefdb551`: /screenshots/transport-dashboard-58fefdb551.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-storymap-bd328e2a5b`: /screenshots/transport-storymap-bd328e2a5b.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-24259ddcec`: /screenshots/transport-dashboard-24259ddcec.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-0c7d78be88`: /screenshots/transport-dashboard-0c7d78be88.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-048f4e4237`: /screenshots/transport-dashboard-048f4e4237.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-storymap-e98ec507f5`: /screenshots/transport-storymap-e98ec507f5.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-c79fcd32aa`: /screenshots/transport-dashboard-c79fcd32aa.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-dashboard-c1e29f0123`: /screenshots/transport-dashboard-c1e29f0123.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-594d7c7ff4`: /screenshots/transport-dashboard-594d7c7ff4.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-storymap-3bc68f337f`: /screenshots/transport-storymap-3bc68f337f.webp — **verified** — تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx
- `transport-dashboard-western-upper-egypt-development-impact`: /screenshots/transport-dashboard-western-upper-egypt-development-impact.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-dashboard-35c11a505b`: /screenshots/transport-dashboard-35c11a505b.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-dashboard-qus-development-impact`: /screenshots/transport-dashboard-qus-development-impact.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-dashboard-kalabsha-development-impact`: /screenshots/transport-dashboard-kalabsha-development-impact.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `transport-dashboard-dabaa-development-impact`: /screenshots/transport-dashboard-dabaa-development-impact.webp — **verified** — تطبيقات_منصة_وزارة_النقل.pptx
- `rsg-destinations`: /screenshots/rsg-destinations-5.webp — **verified** — RSG_Destination_Management_Platform_Detailed_Explainer_EN.pptx

Two new Cloud Run links are unverified app identities and may represent alternate deployment versions of existing apps. No original screenshot has been captured for them yet.
