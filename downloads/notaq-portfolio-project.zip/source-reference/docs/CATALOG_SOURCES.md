# Saad Barghouth / Notaq — Project Catalogue

**93 documented catalog entries** = **23 Notaq entries** + **42 independent Ministry of Transport applications** + **28 other GIS / web / field projects and cases**.

## Coverage and what is *not* confirmed

- The Ministry of Transport program scope is **78 applications** (50 dashboards, 10 experiences, 9 story maps, 5 Web AppBuilder equivalents, 4 gallery apps) as previously specified by the project owner. These are **NOT all separately identified here**.
- **42 independently named and deep-linked transport apps** are verified from the available PowerPoint/Word deliverables. The remaining **36** require their project list or source links before they can be added honestly.
- **23 Notaq project cards** are individually listed on the Notaq public projects page. The website also mentions 180+ delivered work/showcases in marketing, but does **not** expose names and direct links for them all. We have not invented extra names to match this marketing total.
- Some entries represent a software app; some represent a client project or technical case study. All have a stated source or a previous project reference; concepts are not misrepresented as published products.
- A project being listed with a URL sourced from a presentation does not confirm the URL currently resolves. The HTML app provides an exact project link, but live availability requires browsing from an online environment.

## Screenshot integrity

- Only a screenshot from the **corresponding project UI itself** can be considered verified. Ministry of Transport captures were extracted directly from the correspondingly named, URL-linked slide (no AI generation).
- The RSG destinations images were embedded in the relevant app walkthrough presentation.
- No generic artwork is used for missing images. Live preview services can fetch a screenshot of the exact individual site URL if available, but these previews are not claimed as saved or verified.

## Source of direct Transport apps

- `تطبيقات_منصة_وزارة_النقل_الشاشات_الكاملة_RTL.pptx` — 47 slides, including 37 individually linked app slides.
- `تطبيقات_منصة_وزارة_النقل.pptx` — 30 slides, including 23 individually linked app slides.
- `روابط_تطبيقات_منصة_وزارة_النقل.docx` — project name/deep-link table.
- After deduplicating exact destination slugs from three source documents, there are **42** individually linked apps.

## Source and version rules

- `public/data/projects.json` is the editable canonical website dataset.
- `Saad_All_Projects_Master_Inventory.csv` lists every entry and its image and direct link status.
- Related dashboard project summaries have been merged into their exact transport application cards. The migration project was merged into the parent Ministry of Transport platform instead of being counted as a separate deployed website.
- Public GitHub code repositories and the previous user project files substantiate some additional GIS projects; a repository link is placed in `sourceUrl`, not disguised as a running website.

## Transport applications by corridor

### Cairo–Ismailia (5)

- **لوحة مؤشرات الأراضي العمرانية – طريق القاهرة–الإسماعيلية** — https://transport-platform-apps.vercel.app/projects/dashboard-ismailia-urban/index.html?lang=ar
- **لوحة الأثر التنموي للجزء المطور – طريق القاهرة–الإسماعيلية** — https://transport-platform-apps.vercel.app/projects/dashboard-ismailia-development-impact/index.html?lang=ar
- **لوحة مؤشرات الأراضي الزراعية والصناعية – طريق القاهرة–الإسماعيلية** — https://transport-platform-apps.vercel.app/projects/dashboard-ismailia-agriculture/index.html?lang=ar
- **لوحة مؤشرات أسعار الأراضي – طريق القاهرة–الإسماعيلية** — https://transport-platform-apps.vercel.app/projects/dashboard-ismailia-prices/index.html?lang=ar
- **القصة المكانية التفاعلية – طريق القاهرة–الإسماعيلية** — https://transport-platform-apps.vercel.app/projects/storymap-ismailia/index.html?lang=ar

### Cairo–Suez (4)

- **لوحة مؤشرات الأراضي العمرانية – طريق القاهرة - السويس الصحراوي** — https://transport-platform-apps.vercel.app/projects/dashboard-686d8234e8/index.html?lang=ar
- **لوحة مؤشرات الأراضي الزراعية والصناعية – طريق القاهرة - السويس الصحراوي** — https://transport-platform-apps.vercel.app/projects/dashboard-8a75afd782/index.html?lang=ar
- **لوحة مؤشرات أسعار الأراضي – طريق القاهرة - السويس الصحراوي** — https://transport-platform-apps.vercel.app/projects/dashboard-4b4547b902/index.html?lang=ar
- **القصة المكانية – طريق القاهرة - السويس الصحراوي - (السويس الحر)** — https://transport-platform-apps.vercel.app/projects/storymap-739c03527e/index.html?lang=ar

### Dabaa (5)

- **لوحة مؤشرات الأراضي العمرانية – طريق الضبعة** — https://transport-platform-apps.vercel.app/projects/dashboard-c79fcd32aa/index.html?lang=ar
- **لوحة مؤشرات الأراضي الزراعية – طريق الضبعة** — https://transport-platform-apps.vercel.app/projects/dashboard-c1e29f0123/index.html?lang=ar
- **لوحة مؤشرات أسعار الأراضي – طريق الضبعة** — https://transport-platform-apps.vercel.app/projects/dashboard-594d7c7ff4/index.html?lang=ar
- **تطور الأراضي المحيطة بطريق الضبعة** — https://transport-platform-apps.vercel.app/projects/storymap-3bc68f337f/index.html?lang=ar
- **لوحة الأثر الاقتصادي و التنموي– محور الضبعة** — https://transport-platform-apps.vercel.app/projects/dashboard-dabaa-development-impact/index.html?lang=ar

### Eastern Regional Ring Road (5)

- **لوحة مؤشرات الأراضي العمرانية – القوس الشرقي للطريق الدائري الإقليمي وخط الروبيكي** — https://transport-platform-apps.vercel.app/projects/dashboard-ab7611e2f4/index.html?lang=ar
- **لوحة مؤشرات الأراضي الزراعية والصناعية – القوس الشرقي للطريق الدائري الإقليمي وخط الروبيكي** — https://transport-platform-apps.vercel.app/projects/dashboard-b99ee8d8fc/index.html?lang=ar
- **لوحة مؤشرات أسعار الأراضي – القوس الشرقي للطريق الدائري الإقليمي وخط الروبيكي** — https://transport-platform-apps.vercel.app/projects/dashboard-04811fcd6f/index.html?lang=ar
- **القصة المكانية – منطقة الدراسة القوس الشرقى للدائرى الأقليمى و خط الروبيكى** — https://transport-platform-apps.vercel.app/projects/storymap-3678b8faa7/index.html?lang=ar
- **لوحة الأثر الاقتصادي و التنموي–القوس الشرقي للطريق الدائري الإقليمي وخط الروبيكي** — https://transport-platform-apps.vercel.app/projects/dashboard-35c11a505b/index.html?lang=ar

### Kalabsha (5)

- **لوحة مؤشرات الأراضي العمرانية – طريق كلابشة** — https://transport-platform-apps.vercel.app/projects/dashboard-064fecc5d9/index.html?lang=ar
- **لوحة مؤشرات الأراضي الزراعية – طريق كلابشة** — https://transport-platform-apps.vercel.app/projects/dashboard-989c5ff2f9/index.html?lang=ar
- **لوحة مؤشرات أسعار الأراضي – طريق كلابشة** — https://transport-platform-apps.vercel.app/projects/dashboard-2529bc0ae6/index.html?lang=ar
- **تطور الاراضي المحيطة بطريق كلابشة** — https://transport-platform-apps.vercel.app/projects/storymap-3c8f04f4d0/index.html?lang=ar
- **لوحة الأثر الاقتصادي و التنموي– محور كلابشة** — https://transport-platform-apps.vercel.app/projects/dashboard-kalabsha-development-impact/index.html?lang=ar

### Qena–Luxor (4)

- **لوحة مؤشرات الأراضي العمرانية – طريق قنا - الأقصر** — https://transport-platform-apps.vercel.app/projects/dashboard-24259ddcec/index.html?lang=ar
- **لوحة مؤشرات الأراضي الزراعية – طريق قنا - الأقصر** — https://transport-platform-apps.vercel.app/projects/dashboard-0c7d78be88/index.html?lang=ar
- **لوحة مؤشرات أسعار الأراضي – طريق قنا - الأقصر** — https://transport-platform-apps.vercel.app/projects/dashboard-048f4e4237/index.html?lang=ar
- **تطور الاراضي المحيطة بطريق قنا الأقصر** — https://transport-platform-apps.vercel.app/projects/storymap-e98ec507f5/index.html?lang=ar

### Qus (5)

- **لوحة مؤشرات الأراضي العمرانية – طريق قوص** — https://transport-platform-apps.vercel.app/projects/dashboard-3e59ea73ec/index.html?lang=ar
- **لوحة مؤشرات الأراضي الزراعية والصناعية – طريق قوص** — https://transport-platform-apps.vercel.app/projects/dashboard-5a3aaa3b3a/index.html?lang=ar
- **لوحة مؤشرات أسعار الأراضي – طريق قوص** — https://transport-platform-apps.vercel.app/projects/dashboard-58fefdb551/index.html?lang=ar
- **تطور الاراضي المحيطة بطريق قوص** — https://transport-platform-apps.vercel.app/projects/storymap-bd328e2a5b/index.html?lang=ar
- **لوحة الأثر الاقتصادي و التنموي– محور قوص** — https://transport-platform-apps.vercel.app/projects/dashboard-qus-development-impact/index.html?lang=ar

### South Dahshur (4)

- **لوحة مؤشرات الأراضي العمرانية – وصلة دهشور الجنوبية** — https://transport-platform-apps.vercel.app/projects/dashboard-1cb1e42f43/index.html?lang=ar
- **لوحة مؤشرات الأراضي الزراعية والصناعية – وصلة دهشور الجنوبية** — https://transport-platform-apps.vercel.app/projects/dashboard-97daea1db8/index.html?lang=ar
- **لوحة مؤشرات أسعار الأراضي – وصلة دهشور الجنوبية** — https://transport-platform-apps.vercel.app/projects/dashboard-687e564801/index.html?lang=ar
- **القصة المكانية التفاعلية – وصلة دهشور الجنوبية** — https://transport-platform-apps.vercel.app/projects/storymap-dahshur/index.html?lang=ar

### Western Upper Egypt (5)

- **لوحة مؤشرات الأراضي العمرانية – طريق الصعيد الغربي** — https://transport-platform-apps.vercel.app/projects/dashboard-5c855c890c/index.html?lang=ar
- **لوحة مؤشرات الأراضي الزراعية والصناعية – طريق الصعيد الغربي** — https://transport-platform-apps.vercel.app/projects/dashboard-4236f7c912/index.html?lang=ar
- **لوحة مؤشرات أسعار الأراضي – طريق الصعيد الغربي** — https://transport-platform-apps.vercel.app/projects/dashboard-49446055c2/index.html?lang=ar
- **القصة المكانية – طريق الصعيد الغربي** — https://transport-platform-apps.vercel.app/projects/storymap-92d2a80d7f/index.html?lang=ar
- **لوحة الأثر الاقتصادي و التنموي– طريق الصعيد الغربي** — https://transport-platform-apps.vercel.app/projects/dashboard-western-upper-egypt-development-impact/index.html?lang=ar

## Other projects with source repositories or detailed presentation evidence

- **منصة شبكات مرافق مدينة العبور الجديدة** — https://github.com/SAAD23-lgtm/Obour-Overview
- **داشبورد شبكات مرافق العبور الجديدة** — https://github.com/SAAD23-lgtm/Obour-Utilty
- **بوابة استبيانات قطاع مطروح** — https://github.com/SAAD23-lgtm/Matrouh-Sector
- **داشبورد التنمية الاقتصادية لغرب أفريقيا** — https://ae.linkedin.com/posts/saadbarghouth_gis-arcgis-dataanalysis-activity-7305301496668020736-X7Rb
- **نظام إدارة وجهات البحر الأحمر** — RSG_Destination_Management_Platform_Detailed_Explainer_EN.pptx

## Verified coverage

- Verified bundled project-specific covers: 46 / 93
- Pending authentic screenshot: 47 / 93

- Public/demo links listed in the source: 55.
- Categories: {'Education': 6, 'Business': 6, 'Platforms': 5, 'Systems': 3, 'Commerce': 4, 'AI': 2, 'Culture': 1, 'GIS': 30, 'Dashboards': 36}

