import { useCallback, useEffect, useMemo, useRef, useState, type KeyboardEvent, type ReactNode } from 'react';
import { ArrowRight, ArrowUpRight, ExternalLink, Grid2X2, Layers2, List, Moon, Search, Sun, X } from 'lucide-react';

type Lang = 'en' | 'ar';
type View = 'grid' | 'list';
type Sort = 'featured' | 'az' | 'za';
type Project = {
  id: string; en: string; ar: string; group: string; sub: string; desc: string; arDesc: string;
  url: string | null; sourceUrl: string | null; tags: string[]; featured: boolean; origin: string;
  status: string; screenshot: string | null; gallery?: string[]; road?: string; parentId?: string;
  duplicateOf?: string;
  screenshotAudit?: { state?: string; evidence?: string; source?: string | null };
};
const categories = ['All', 'GIS', 'Dashboards', 'Platforms', 'Systems', 'Business', 'Commerce', 'Education', 'AI', 'Culture'];
const categoryNames: Record<string, [string, string]> = {
  All: ['All work', 'كل الأعمال'], GIS: ['GIS & mapping', 'نظم المعلومات الجغرافية'], Dashboards: ['Dashboards', 'لوحات المعلومات'],
  Platforms: ['Digital platforms', 'المنصات الرقمية'], Systems: ['Enterprise systems', 'أنظمة المؤسسات'],
  Business: ['Websites', 'المواقع الإلكترونية'], Commerce: ['Commerce', 'التجارة الإلكترونية'],
  Education: ['Education', 'التعليم'], AI: ['AI & automation', 'الذكاء الاصطناعي'], Culture: ['Digital experiences', 'التجارب الرقمية'],
};
const copy = {
  en: {
    eyebrow: 'SAAD BARGHOUTH  /  NOTAQ · EGYPT', titleA: 'Spatial thinking.', titleB: 'Digital made useful.',
    desc: 'A working archive of geospatial intelligence, public infrastructure, enterprise systems and digital products — built for places, people and the decisions between them.',
    introMeta: 'INDEPENDENT DIGITAL PRACTICE', cairo: '30°02′N  ·  31°14′E  ·  CAIRO',
    archiveKicker: 'THE PROJECT ARCHIVE / 01', archiveTitle: 'Work, in its many coordinates.', archiveDesc: 'Explore projects across GIS, transport, infrastructure, enterprise systems, dashboards, education and the web. Alternate deployments remain connected to their parent record instead of appearing as separate projects.',
    search: 'Search projects, technologies, sectors…', sort: 'Order', featured: 'Featured first', az: 'Name A–Z', za: 'Name Z–A',
    allOrigins: 'All collections', liveOnly: 'Live links only', road: 'All corridors', results: 'projects shown', reset: 'Reset filters',
    open: 'OPEN PROJECT', details: 'Explore details', noLiveCard: 'No live URL recorded', unavailable: 'PROJECT IMAGE NOT VERIFIED', missing: 'No project-specific screenshot is available in the archive.',
    live: 'Live link', catalog: 'Catalog entry', case: 'Case study', concept: 'Concept', preview: 'Deployment preview',
    status: 'STATUS', collection: 'COLLECTION', type: 'PROJECT TYPE', tags: 'TOOLS & SUBJECTS', gallery: 'VERIFIED PROJECT SCREENS',
    related: 'RELATED RECORDS', overview: 'OVERVIEW', direct: 'Visit live project', source: 'Open source record', noLink: 'No direct project link is recorded for this entry.',
    evidence: 'Only original project screenshots marked verified in the catalog are shown here. Missing screenshots are clearly identified; nothing has been substituted.',
    emptyTitle: 'No records in this view.', empty: 'Change a filter or clear your search to return to the complete archive.',
    footerTitle: 'Build for the real world.', footerCopy: 'Saad Barghouth · Notaq. An independent digital practice based in Egypt, working across geospatial systems and useful digital experiences.',
    identity: 'Professional site', contact: 'Discuss a project', detailsTitle: 'SELECTED PROJECTS / VERIFIED SCREENS', count: 'DISTINCT PROJECTS', available: 'LIVE LINKS', close: 'Close project details', sourceOrigin: 'Collection',
    sourceNotaq: 'Notaq', sourceGIS: 'GIS / spatial', sourceTransport: 'Transport', sourceWeb: 'Digital products', projectIndex: 'ARCHIVE RECORD',
  },
  ar: {
    eyebrow: 'سعد برغوث  /  نُطق · مصر', titleA: 'فكر مكاني.', titleB: 'تقنية تخدم الواقع.',
    desc: 'أرشيف عملي للذكاء المكاني والبنية التحتية والأنظمة المؤسسية والمنتجات الرقمية — حلول مرتبطة بالمكان والناس والقرارات.',
    introMeta: 'ممارسة رقمية مستقلة', cairo: '٣٠°٠٢′ شمالاً  ·  ٣١°١٤′ شرقاً  ·  القاهرة',
    archiveKicker: 'أرشيف المشاريع / ٠١', archiveTitle: 'أعمال بإحداثيات متعددة.', archiveDesc: 'استكشف مشاريع نظم المعلومات الجغرافية والنقل والبنية التحتية والأنظمة ولوحات المعلومات والتعليم والويب. تبقى روابط النشر البديلة مرتبطة بسجل المشروع الأصلي ولا تظهر كمشاريع مستقلة.',
    search: 'ابحث باسم المشروع أو التقنية أو المجال…', sort: 'الترتيب', featured: 'المميزة أولاً', az: 'الاسم أ–ي', za: 'الاسم ي–أ',
    allOrigins: 'كل المجموعات', liveOnly: 'روابط مباشرة فقط', road: 'كل الطرق', results: 'مشاريع ظاهرة', reset: 'إعادة ضبط الفلاتر',
    open: 'زيارة المشروع', details: 'استكشف التفاصيل', noLiveCard: 'لا يوجد رابط مباشر مسجل', unavailable: 'صورة المشروع غير موثقة', missing: 'لا تتوفر في الأرشيف صورة مؤكدة لهذا المشروع.',
    live: 'رابط مباشر', catalog: 'سجل فهرس', case: 'دراسة حالة', concept: 'تصور', preview: 'معاينة منشورة',
    status: 'الحالة', collection: 'المجموعة', type: 'نوع المشروع', tags: 'التقنيات والموضوعات', gallery: 'صور مؤكدة من المشروع',
    related: 'سجلات ذات صلة', overview: 'نبذة', direct: 'زيارة المشروع', source: 'فتح سجل المصدر', noLink: 'لا يوجد رابط مباشر مسجل لهذا العنصر.',
    evidence: 'نعرض فقط صور المشاريع الأصلية المصنفة موثقة في الأرشيف. نوضح غياب الصور عند عدم توفرها ولا نستخدم صوراً بديلة.',
    emptyTitle: 'لا توجد سجلات في هذا العرض.', empty: 'غيّر أحد الفلاتر أو امسح البحث للعودة إلى الأرشيف الكامل.',
    footerTitle: 'تقنية للعالم الحقيقي.', footerCopy: 'سعد برغوث · نُطق. ممارسة رقمية مستقلة من مصر، تعمل على الأنظمة المكانية والتجارب الرقمية المفيدة.',
    identity: 'الموقع المهني', contact: 'تواصل بخصوص مشروع', detailsTitle: 'مشاريع مختارة / لقطات موثقة', count: 'مشروعاً متميزاً', available: 'رابطاً مباشراً', close: 'إغلاق تفاصيل المشروع', sourceOrigin: 'المجموعة',
    sourceNotaq: 'نُطق', sourceGIS: 'GIS / مكاني', sourceTransport: 'النقل', sourceWeb: 'منتجات رقمية', projectIndex: 'سجل الأرشيف',
  },
} as const;

function IconButton({ label, onClick, children, testId }: { label: string; onClick: () => void; children: ReactNode; testId: string }) {
  return <button className="icon-button" type="button" aria-label={label} title={label} onClick={onClick} data-testid={testId}>{children}</button>;
}
function Evidence({ project, lang, className = '' }: { project: Project; lang: Lang; className?: string }) {
  const verified = project.screenshotAudit?.state === 'verified';
  const img = verified ? project.screenshot || project.gallery?.[0] || null : null;
  return <div className={`unavailable ${className}`} data-testid={`evidence-${project.id}`}>
    {img ? <img src={img} alt={lang === 'ar' ? `لقطة موثقة: ${project.ar}` : `Verified project screen: ${project.en}`} loading="lazy" /> :
      <><div className="unavailable-top"><span>{lang === 'ar' ? 'أرشيف المشاريع / دليل بصري' : 'PROJECT ARCHIVE / VISUAL EVIDENCE'}</span><span className="unavailable-mark" aria-hidden="true"><Layers2 size={14} strokeWidth={1.5} /></span></div>
        <div className="unavailable-label">{copy[lang].unavailable}<small>{copy[lang].missing}</small></div></>}
  </div>;
}
function ProjectCard({ project, lang, index, onOpen }: { project: Project; lang: Lang; index: number; onOpen: (id: string, source: HTMLElement) => void }) {
  const t = copy[lang]; const name = lang === 'ar' ? project.ar : project.en;
  const description = lang === 'ar' ? project.arDesc : project.desc;
  const status = project.status === 'live' ? t.live : project.status === 'preview' ? t.preview : project.status === 'concept' ? t.concept : project.status === 'case' ? t.case : t.catalog;
  return <article className="project-card" data-testid={`card-project-${project.id}`}>
    <div className="card-visual"><Evidence project={project} lang={lang} /><span className="card-status" data-testid={`status-project-${project.id}`}>{status}</span></div>
    <div className="card-body"><div className="card-kicker"><span>{project.group}</span><span>{project.origin}{project.road ? ` / ${project.road}` : ''}</span></div>
      <h3 className="card-title" dir={lang === 'ar' ? 'rtl' : 'ltr'}>{name}</h3><p className="card-description" dir={lang === 'ar' ? 'rtl' : 'ltr'}>{description}</p>
      <div className="tag-row">{project.tags.slice(0, 3).map(tag => <span className="tag" key={tag}>{tag}</span>)}</div>
      <div className="card-footer"><span className="project-number">N / {String(index + 1).padStart(2, '0')}</span><div className="card-actions">
        <button className="card-action details-action" type="button" onClick={e => onOpen(project.id, e.currentTarget)} data-testid={`button-details-${project.id}`}>{t.details}<ArrowUpRight size={13} /></button>
        {project.url ? <a className="card-action project-action" href={project.url} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()} data-testid={`link-project-${project.id}`}>{t.open}<ExternalLink size={12} /></a> : <span className="card-action no-project-url" aria-disabled="true" data-testid={`status-no-live-url-${project.id}`}>{t.noLiveCard}</span>}
      </div></div>
    </div>
  </article>;
}
function FeaturedCard({ project, lang, index, onOpen }: { project: Project; lang: Lang; index: number; onOpen: (id: string, source: HTMLElement) => void }) {
  const title = lang === 'ar' ? project.ar : project.en;
  const description = lang === 'ar' ? project.arDesc : project.desc;
  const image = project.screenshot!;
  return <article className={`featured-card featured-card-${index + 1}`} data-testid={`featured-project-${project.id}`}>
    <div className="featured-image"><img src={image} alt={lang === 'ar' ? `لقطة موثقة من ${title}` : `Verified project screenshot: ${title}`} loading="lazy" /><span className="featured-index">SELECTED / {String(index + 1).padStart(2, '0')}</span></div>
    <div className="featured-copy"><div className="featured-meta"><span>{project.group}</span><span>{project.origin}{project.road ? ` / ${project.road}` : ''}</span></div>
      <h3 dir={lang === 'ar' ? 'rtl' : 'ltr'}>{title}</h3><p dir={lang === 'ar' ? 'rtl' : 'ltr'}>{description}</p>
      <div className="tag-row">{project.tags.slice(0, 4).map(tag => <span className="tag" key={tag}>{tag}</span>)}</div>
      <div className="featured-actions"><button className="card-action details-action" type="button" onClick={e => onOpen(project.id, e.currentTarget)} data-testid={`button-featured-details-${project.id}`}>{copy[lang].details}<ArrowUpRight size={14} /></button>
        {project.url ? <a className="card-action project-action" href={project.url} target="_blank" rel="noreferrer" data-testid={`link-featured-project-${project.id}`}>{copy[lang].open}<ExternalLink size={13} /></a> : <span className="card-action no-project-url" data-testid={`status-featured-no-live-url-${project.id}`}>{copy[lang].noLiveCard}</span>}
      </div>
    </div>
  </article>;
}
function ProjectDialog({ project, projects, lang, onClose, onSelect }: { project: Project; projects: Project[]; lang: Lang; onClose: () => void; onSelect: (id: string, source: HTMLElement) => void }) {
  const t = copy[lang]; const name = lang === 'ar' ? project.ar : project.en; const desc = lang === 'ar' ? project.arDesc : project.desc;
  const dialogRef = useRef<HTMLElement>(null); const closeRef = useRef<HTMLButtonElement>(null);
  const verifiedImages = project.screenshotAudit?.state === 'verified' ? [...new Set([project.screenshot, ...(project.gallery || [])].filter((x): x is string => !!x))] : [];
  const alternateDeployments = projects.filter(p => p.duplicateOf === project.id);
  const contextualRelated = projects.filter(p => p.id !== project.id && p.duplicateOf !== project.id && (p.parentId === project.id || project.parentId === p.id || p.group === project.group && p.origin === project.origin));
  const related = [...alternateDeployments, ...contextualRelated.slice(0, Math.max(0, 5 - alternateDeployments.length))];
  const status = project.status === 'live' ? t.live : project.status === 'preview' ? t.preview : project.status === 'concept' ? t.concept : project.status === 'case' ? t.case : t.catalog;
  useEffect(() => { closeRef.current?.focus(); }, []);
  const trapFocus = (e: KeyboardEvent) => {
    if (e.key !== 'Tab') return;
    const nodes = dialogRef.current?.querySelectorAll<HTMLElement>('button:not([disabled]),a[href],[tabindex="0"]');
    if (!nodes?.length) return;
    const first = nodes[0]; const last = nodes[nodes.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  };
  return <div className="dialog-backdrop" role="presentation" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <section className="dialog" role="dialog" aria-modal="true" aria-labelledby="project-dialog-title" ref={dialogRef} onKeyDown={trapFocus} data-testid="dialog-project">
      <div className="dialog-head"><span>{t.projectIndex} · {project.id}</span><button className="dialog-close" type="button" onClick={onClose} aria-label={t.close} ref={closeRef} data-testid="button-close-project"><X size={17} /></button></div>
      <div className="dialog-content">
        <div className="dialog-visual"><Evidence project={project} lang={lang} /></div>
        <div className="dialog-index"><span>{project.group} / {project.origin}</span><span>{status}</span></div>
        <h2 id="project-dialog-title" dir={lang === 'ar' ? 'rtl' : 'ltr'}>{name}</h2>
        <p className="dialog-description" dir={lang === 'ar' ? 'rtl' : 'ltr'}>{desc}</p>
        <div className="detail-meta"><div><span>{t.type}</span><strong>{project.group}{project.sub ? ` · ${project.sub}` : ''}</strong></div><div><span>{t.collection}</span><strong>{project.origin}{project.road ? ` · ${project.road}` : ''}</strong></div><div><span>{t.status}</span><strong>{status}</strong></div><div><span>{lang === 'ar' ? 'معرّف السجل' : 'ARCHIVE ID'}</span><strong className="mono">{project.id}</strong></div></div>
        <section className="detail-section"><h3>{t.overview}</h3><p className="dialog-description" dir={lang === 'ar' ? 'rtl' : 'ltr'}>{desc}</p></section>
        <section className="detail-section"><h3>{t.tags}</h3><div className="detail-tags">{project.tags.length ? project.tags.map(tag => <span className="tag" key={tag}>{tag}</span>) : <span className="tag">{project.group}</span>}</div></section>
        {verifiedImages.length > 1 && <section className="detail-section"><h3>{t.gallery}</h3><div className="gallery">{verifiedImages.map((src, i) => <a key={src} href={src} target="_blank" rel="noreferrer" aria-label={`${name} ${i + 1}`} data-testid={`link-gallery-${project.id}-${i}`}><img src={src} alt={`${name} — ${i + 1}`} loading="lazy" /></a>)}</div></section>}
        <div className="detail-links">{project.url ? <a className="detail-link" href={project.url} target="_blank" rel="noreferrer" data-testid={`link-live-${project.id}`}>{t.direct}<ExternalLink size={14} /></a> : <span className="detail-link" aria-disabled="true">{t.noLink}</span>}
          {project.sourceUrl && <a className="detail-link secondary" href={project.sourceUrl} target="_blank" rel="noreferrer" data-testid={`link-source-${project.id}`}>{t.source}<ArrowUpRight size={14} /></a>}</div>
        {!verifiedImages.length && <p className="evidence-note">{project.screenshotAudit?.evidence || t.evidence}</p>}
        {related.length > 0 && <section className="detail-section"><h3>{t.related}</h3><div className="related">{related.map(r => <button key={r.id} type="button" onClick={e => onSelect(r.id, e.currentTarget)} data-testid={`button-related-${r.id}`}><span>{lang === 'ar' ? r.ar : r.en}</span><span>{r.duplicateOf === project.id ? (lang === 'ar' ? 'نشر بديل · معاينة' : 'Alternate deployment · preview') : `${r.group} · ${r.origin}`}</span></button>)}</div></section>}
      </div>
    </section>
  </div>;
}
function VerifiedHeroVisual({ projects, lang }: { projects: Project[]; lang: Lang }) {
  const primary = projects.find(p => p.id === 'transport' && p.screenshotAudit?.state === 'verified' && p.screenshot);
  const secondary = projects.find(p => p.id === 'smart-infra' && p.screenshotAudit?.state === 'verified' && p.screenshot);
  if (!primary || !secondary) return <div className="hero-evidence-loading" aria-hidden="true" />;
  return <div className="hero-evidence" aria-label={lang === 'ar' ? 'لقطات أصلية موثقة من المشاريع' : 'Verified original project screenshots'}>
    <figure className="hero-shot hero-shot-main"><img src={primary.screenshot!} alt={lang === 'ar' ? `لقطة حقيقية من ${primary.ar}` : `Original screen from ${primary.en}`} fetchPriority="high" /><figcaption>{primary.group} / {primary.origin} <span>01</span></figcaption></figure>
    <figure className="hero-shot hero-shot-overlay"><img src={secondary.screenshot!} alt={lang === 'ar' ? `لقطة حقيقية من ${secondary.ar}` : `Original screen from ${secondary.en}`} loading="lazy" /><figcaption>{secondary.group} / {secondary.origin} <span>02</span></figcaption></figure>
    <span className="hero-evidence-label">{lang === 'ar' ? 'واجهات أصلية من الأرشيف' : 'ORIGINAL PROJECT SCREENS'}</span>
  </div>;
}
function App() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [error, setError] = useState(false);
  const [lang, setLang] = useState<Lang>(() => new URLSearchParams(window.location.search).get('lang') === 'ar' ? 'ar' : 'en');
  const [dark, setDark] = useState(() => localStorage.getItem('notaq-theme') === 'dark');
  const [group, setGroup] = useState('All'); const [origin, setOrigin] = useState('all'); const [road, setRoad] = useState('all');
  const [query, setQuery] = useState(''); const [sort, setSort] = useState<Sort>('featured'); const [liveOnly, setLiveOnly] = useState(false); const [view, setView] = useState<View>('grid'); const [selectedId, setSelectedId] = useState<string | null>(() => new URLSearchParams(window.location.search).get('project'));
  const searchRef = useRef<HTMLInputElement>(null); const returnFocus = useRef<HTMLElement | null>(null); const t = copy[lang];
  useEffect(() => {
    let alive = true;
    fetch(`${import.meta.env.BASE_URL}data/projects.json`).then(response => { if (!response.ok) throw new Error('Project index unavailable'); return response.json() as Promise<Project[]>; })
      .then(data => { if (alive) setProjects(data); }).catch(() => { if (alive) setError(true); });
    return () => { alive = false; };
  }, []);
  useEffect(() => {
    if (projects.length && selectedId && !projects.some(p => p.id === selectedId)) setSelectedId(null);
  }, [projects, selectedId]);
  useEffect(() => {
    document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.classList.toggle('dark', dark);
    document.title = lang === 'ar' ? 'سعد برغوث · نُطق — أرشيف المشاريع' : 'Saad Barghouth · Notaq — Project Archive';
  }, [lang, dark]);
  useEffect(() => { localStorage.setItem('notaq-theme', dark ? 'dark' : 'light'); }, [dark]);
  useEffect(() => {
    if (!selectedId) return;
    const previous = document.activeElement as HTMLElement | null; const priorOverflow = document.body.style.overflow; document.body.style.overflow = 'hidden';
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setSelectedId(null); };
    window.addEventListener('keydown', key);
    return () => { window.removeEventListener('keydown', key); document.body.style.overflow = priorOverflow; (returnFocus.current || previous)?.focus?.(); };
  }, [selectedId]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === '/' && !selectedId && !(e.target instanceof HTMLInputElement) && !(e.target instanceof HTMLTextAreaElement)) { e.preventDefault(); searchRef.current?.focus(); } };
    window.addEventListener('keydown', onKey); return () => window.removeEventListener('keydown', onKey);
  }, [selectedId]);
  const normalized = (s: string) => s.toLocaleLowerCase().normalize('NFC');
  const matches = useCallback((p: Project, skip: 'group' | 'origin' | null = null) => {
    const q = normalized(query.trim());
    return (skip === 'group' || group === 'All' || p.group === group)
      && (skip === 'origin' || origin === 'all' || p.origin === origin)
      && (road === 'all' || p.road === road)
      && (!liveOnly || p.status === 'live' && !!p.url)
      && (!q || [p.en, p.ar, p.desc, p.arDesc, p.sub, p.group, p.origin, p.road || '', p.id, ...p.tags].some(v => normalized(v).includes(q)));
  }, [group, origin, road, liveOnly, query]);
  const distinctProjects = useMemo(() => projects.filter(p => !p.duplicateOf), [projects]);
  const shown = useMemo(() => {
    const result = distinctProjects.filter(p => matches(p));
    return result.sort((a, b) => sort === 'az' ? (lang === 'ar' ? a.ar : a.en).localeCompare(lang === 'ar' ? b.ar : b.en, lang) : sort === 'za' ? (lang === 'ar' ? b.ar : b.en).localeCompare(lang === 'ar' ? a.ar : a.en, lang) : Number(b.featured) - Number(a.featured) || projects.indexOf(a) - projects.indexOf(b));
  }, [distinctProjects, projects, matches, sort, lang]);
  const roads = useMemo(() => [...new Set(distinctProjects.map(p => p.road).filter((x): x is string => !!x))].sort(), [distinctProjects]);
  const filtered = group !== 'All' || origin !== 'all' || road !== 'all' || query.length > 0 || liveOnly;
  const open = (id: string, source: HTMLElement) => { returnFocus.current = source; setSelectedId(id); const u = new URL(window.location.href); u.searchParams.set('project', id); window.history.replaceState({}, '', u); };
  const closeProject = () => { setSelectedId(null); const u = new URL(window.location.href); u.searchParams.delete('project'); window.history.replaceState({}, '', u); };
  const reset = () => { setGroup('All'); setOrigin('all'); setRoad('all'); setQuery(''); setLiveOnly(false); setSort('featured'); };
  const switchLanguage = () => { const next = lang === 'en' ? 'ar' : 'en'; setLang(next); const u = new URL(window.location.href); if (next === 'ar') u.searchParams.set('lang', 'ar'); else u.searchParams.delete('lang'); window.history.replaceState({}, '', u); };
  const liveCount = distinctProjects.filter(p => p.status === 'live' && !!p.url).length;
  const selected = projects.find(p => p.id === selectedId) || null;
  const featuredIds = ['transport', 'smart-infra', 'gis-automator', 'transport-dashboard-ismailia-development-impact', 'rsg-destinations'];
  const selectedFeatures = featuredIds.map(id => distinctProjects.find(p => p.id === id)).filter((p): p is Project => !!p && p.screenshotAudit?.state === 'verified' && !!p.screenshot?.startsWith('/screenshots/'));
  const originNames: Record<string, string> = { Notaq: t.sourceNotaq, GIS: t.sourceGIS, Transport: t.sourceTransport, Web: t.sourceWeb, Concept: lang === 'ar' ? 'تصورات' : 'Concepts' };
  return <div className="app">
    <header className="topbar"><a href="#top" className="brand" aria-label="Saad Barghouth — Notaq" data-testid="link-home"><span className="brand-mark">ن</span><span><span className="brand-name">SAAD BARGHOUTH</span><span className="brand-sub">NOTAQ / PROJECT ARCHIVE</span></span></a>
      <div className="head-tools"><span className="head-count" data-testid="text-catalog-count">{String(distinctProjects.length).padStart(2, '0')} / {t.count}</span>
        <a className="header-archive" href="#archive" data-testid="link-header-archive">{lang === 'ar' ? 'الأرشيف' : 'Archive'}<ArrowRight size={13} /></a>
        <IconButton label={dark ? (lang === 'ar' ? 'الوضع الفاتح' : 'Switch to light mode') : (lang === 'ar' ? 'الوضع الداكن' : 'Switch to dark mode')} onClick={() => setDark(v => !v)} testId="button-theme">{dark ? <Sun size={16} /> : <Moon size={16} />}</IconButton>
        <button className="language-button" type="button" onClick={switchLanguage} data-testid="button-language">{lang === 'en' ? 'عربي' : 'English'}</button>
        <a className="header-cta" href="https://www.barghouth.me/contact" target="_blank" rel="noreferrer" aria-label={t.contact} data-testid="link-header-contact"><span className="header-cta-label">{t.contact}</span><ArrowUpRight size={13} /></a>
      </div>
    </header>
    <main id="top" className="wrap">
      <section className="intro" aria-labelledby="intro-title"><div className="intro-copy"><div className="eyebrow">{t.eyebrow}</div><h1 id="intro-title">{t.titleA}<br /><em>{t.titleB}</em></h1>
        <p className="intro-desc">{t.desc}</p><div className="intro-line"><span>{t.introMeta}</span><span>—</span><span>{t.cairo}</span></div>
        <span className="coordinates">{distinctProjects.length} {lang === 'ar' ? 'مشروعاً متميزاً' : 'DISTINCT PROJECTS'}</span></div><VerifiedHeroVisual projects={distinctProjects} lang={lang} /></section>
      {selectedFeatures.length > 0 && <section className="featured-section" aria-labelledby="featured-title" data-testid="section-featured-projects">
        <div className="featured-heading"><div><div className="eyebrow">{t.detailsTitle}</div><h2 id="featured-title">{lang === 'ar' ? 'نماذج من العمل.' : 'A closer look.'}</h2></div><p>{lang === 'ar' ? 'لقطات أصلية مرتبطة بسجلاتها ومصنفة موثقة في أرشيف المشاريع.' : 'Original screens, shown only where the catalog has verified project-specific evidence.'}</p></div>
        <div className="featured-grid">{selectedFeatures.map((p, i) => <FeaturedCard key={p.id} project={p} lang={lang} index={i} onOpen={open} />)}</div>
      </section>}
      <section className="archive-intro" id="archive"><div className="archive-title"><div className="eyebrow">{t.archiveKicker}</div><h2>{t.archiveTitle}</h2></div><p className="archive-description">{t.archiveDesc}</p></section>
      <section aria-label={lang === 'ar' ? 'تصفية المشاريع' : 'Filter projects'}>
        <div className="filters"><div className="filter-top">
          <label className="search-wrap"><Search size={17} aria-hidden="true" /><input ref={searchRef} type="search" value={query} onChange={e => setQuery(e.target.value)} placeholder={t.search} aria-label={t.search} data-testid="input-project-search" /><kbd className="mono">/</kbd></label>
          <select className="sort-select" value={sort} aria-label={t.sort} onChange={e => setSort(e.target.value as Sort)} data-testid="select-sort"><option value="featured">{t.featured}</option><option value="az">{t.az}</option><option value="za">{t.za}</option></select>
          <div className="view-toggle" role="group" aria-label={lang === 'ar' ? 'طريقة العرض' : 'View mode'}><button type="button" className={view === 'grid' ? 'active' : ''} aria-label="Grid view" aria-pressed={view === 'grid'} onClick={() => setView('grid')} data-testid="button-view-grid"><Grid2X2 size={15} /></button><button type="button" className={view === 'list' ? 'active' : ''} aria-label="List view" aria-pressed={view === 'list'} onClick={() => setView('list')} data-testid="button-view-list"><List size={16} /></button></div>
        </div>
        <div className="filter-bottom"><div className="chip-row" role="group" aria-label={lang === 'ar' ? 'التصنيفات' : 'Categories'}>
          {categories.map(category => {
            const count = distinctProjects.filter(p => (category === 'All' || p.group === category) && matches(p, 'group')).length;
            const label = categoryNames[category][lang === 'ar' ? 1 : 0];
            return <button type="button" className={`filter-chip ${group === category ? 'active' : ''}`} key={category} onClick={() => setGroup(category)} aria-pressed={group === category} data-testid={`filter-category-${category.toLowerCase()}`}>{label}<small>{count}</small></button>;
          })}
        </div><div className="filter-options">
          <select className="origin-select" aria-label={t.allOrigins} value={origin} onChange={e => setOrigin(e.target.value)} data-testid="select-origin"><option value="all">{t.allOrigins} · {distinctProjects.filter(p => matches(p, 'origin')).length}</option>{[...new Set(distinctProjects.map(p => p.origin))].sort().map(o => <option value={o} key={o}>{originNames[o] || o} · {distinctProjects.filter(p => p.origin === o && matches(p, 'origin')).length}</option>)}</select>
          {roads.length > 0 && <select className="road-select" aria-label={t.road} value={road} onChange={e => setRoad(e.target.value)} data-testid="select-road"><option value="all">{t.road}</option>{roads.map(r => <option value={r} key={r}>{r}</option>)}</select>}
          <label className="live-toggle"><input type="checkbox" checked={liveOnly} onChange={e => setLiveOnly(e.target.checked)} data-testid="toggle-live-only" />{t.liveOnly}</label>
        </div></div></div>
        <div className="result-line"><span><strong className="result-number" data-testid="text-result-count">{String(shown.length).padStart(2, '0')}</strong> / {distinctProjects.length} {t.results}</span>{filtered ? <button className="reset-button" onClick={reset} type="button" data-testid="button-reset-filters">{t.reset} ×</button> : <span>{liveCount} {t.available}</span>}</div>
        {error ? <div className="empty" role="alert"><h3>{lang === 'ar' ? 'تعذر تحميل فهرس المشاريع' : 'The project index could not be loaded.'}</h3><p>{lang === 'ar' ? 'تأكد من تشغيل الموقع عبر خادم الويب.' : 'Please serve the app from its configured web root and reload.'}</p><button className="reset-button" onClick={() => window.location.reload()} data-testid="button-retry">{lang === 'ar' ? 'إعادة المحاولة' : 'Try again'}</button></div> :
          projects.length === 0 ? <div className="loading" aria-label={lang === 'ar' ? 'جارٍ تحميل المشاريع' : 'Loading projects'}>{[1, 2, 3].map(n => <div className="skeleton" key={n} />)}</div> :
            shown.length ? <div className={`project-grid ${view}`} data-testid="project-archive">{shown.map(p => <ProjectCard key={p.id} project={p} lang={lang} index={distinctProjects.indexOf(p)} onOpen={open} />)}</div> :
              <div className="empty" data-testid="empty-project-results"><h3>{t.emptyTitle}</h3><p>{t.empty}</p><button className="reset-button" onClick={reset} data-testid="button-empty-reset">{t.reset}</button></div>}
      </section>
      <footer className="footer"><div className="footer-main"><div className="footer-title">SAAD <span>×</span> NOTAQ</div><p className="footer-copy">{t.footerCopy}</p><a className="footer-link" href="https://www.barghouth.me/" target="_blank" rel="noreferrer" data-testid="link-professional-portfolio">{t.identity}<ArrowRight size={15} /></a></div>
        <div className="footer-meta"><span>{t.footerTitle}</span><span>{t.cairo}</span><span>© SAAD BARGHOUTH / NOTAQ</span></div></footer>
    </main>
    {selected && <ProjectDialog project={selected} projects={projects} lang={lang} onClose={closeProject} onSelect={(id, source) => { returnFocus.current = source; setSelectedId(id); const u = new URL(window.location.href); u.searchParams.set('project', id); window.history.replaceState({}, '', u); }} />}
  </div>;
}
export default App;